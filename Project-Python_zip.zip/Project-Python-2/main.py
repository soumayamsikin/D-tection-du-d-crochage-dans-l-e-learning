"""
Application de Gestion des Emplois du Temps Universitaire
Point d'entrée principal de l'application

Ce programme permet de gérer automatiquement les emplois du temps d'un 
établissement universitaire avec trois profils d'utilisateurs:
- Administrateur: Gère les emplois du temps, salles, enseignants
- Enseignant: Consulte son emploi du temps, fait des réservations
- Étudiant: Consulte l'emploi du temps de sa filière

Comptes de test:
- Admin: admin@univ.ma / admin123
- Enseignant: ahmed.benali@univ.ma / enseignant123
- Étudiant: farouk@univ.ma / etudiant123

Usage:  
    python main.py
"""

import sys
import os

# Ajouter le répertoire courant au path pour les imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import de l'application
from vues.application import Application


def main():
    """Point d'entrée principal de l'application."""
    print("=" * 50)
    print("  Gestion des Emplois du Temps Universitaire")
    print("=" * 50)
    print("\nDémarrage de l'application...")
    print("\nComptes de test disponibles:")
    print("  - Admin: admin@univ.ma / admin123")
    print("  - Enseignant: ahmed.benali@univ.ma / enseignant123")
    print("  - Étudiant: farouk@univ.ma / etudiant123")
    print("\n")
    
    # Créer et lancer l'application
    app = Application()
    app.mainloop()


if __name__ == "__main__":
    main()
