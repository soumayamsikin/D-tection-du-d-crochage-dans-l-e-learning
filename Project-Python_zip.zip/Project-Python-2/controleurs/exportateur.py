# -*- coding: utf-8 -*-
"""
Exportateur - Gère l'exportation des emplois du temps
"""

import csv
import json
import os
from reportlab.lib import colors
from reportlab.lib.pagesizes import landscape, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from PIL import Image, ImageDraw, ImageFont

class Exportateur:
    """
    Classe pour gérer les exports (PDF, CSV, JSON, Image).
    """
    
    def __init__(self, gestionnaire_donnees):
        """Initialise l'exportateur."""
        self.gestionnaire = gestionnaire_donnees
        self.styles = getSampleStyleSheet()

    def exporter_json(self, seances, chemin_fichier):
        """Exporte les séances en JSON."""
        donnees = []
        for s in seances:
            # Enrichir les données pour l'export
            module = self.gestionnaire.trouver_module_par_id(s.module_id)
            salle = self.gestionnaire.trouver_salle_par_id(s.salle_id)
            groupe = self.gestionnaire.trouver_groupe_par_id(s.groupe_id)
            enseignant = self.gestionnaire.trouver_enseignant_par_id(s.enseignant_id)
            creneau = self.gestionnaire.trouver_creneau_par_id(s.creneau_id)
            
            donnees.append({
                "jour": s.jour,
                "creneau": creneau.label if creneau else s.creneau_id,
                "module": module.nom if module else s.module_id,
                "salle": salle.nom if salle else s.salle_id,
                "groupe": groupe.nom if groupe else s.groupe_id,
                "enseignant": self.gestionnaire.trouver_utilisateur_par_id(enseignant.utilisateur_id).nom_complet if enseignant else s.enseignant_id
            })
            
        with open(chemin_fichier, 'w', encoding='utf-8') as f:
            json.dump(donnees, f, indent=4, ensure_ascii=False)
            
    def exporter_csv(self, seances, chemin_fichier):
        """Exporte les séances en CSV."""
        with open(chemin_fichier, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f, delimiter=';')
            # En-têtes
            writer.writerow(["Jour", "Créneau", "Module", "Salle", "Groupe", "Enseignant"])
            
            for s in seances:
                module = self.gestionnaire.trouver_module_par_id(s.module_id)
                salle = self.gestionnaire.trouver_salle_par_id(s.salle_id)
                groupe = self.gestionnaire.trouver_groupe_par_id(s.groupe_id)
                enseignant = self.gestionnaire.trouver_enseignant_par_id(s.enseignant_id)
                creneau = self.gestionnaire.trouver_creneau_par_id(s.creneau_id)
                
                nom_enseignant = ""
                if enseignant:
                    user = self.gestionnaire.trouver_utilisateur_par_id(enseignant.utilisateur_id)
                    if user:
                        nom_enseignant = user.nom_complet
                
                writer.writerow([
                    s.jour,
                    creneau.label if creneau else s.creneau_id,
                    module.nom if module else s.module_id,
                    salle.nom if salle else s.salle_id,
                    groupe.nom if groupe else s.groupe_id,
                    nom_enseignant
                ])

    def exporter_pdf(self, seances, chemin_fichier, titre="Emploi du Temps"):
        """Exporte les séances en PDF."""
        doc = SimpleDocTemplate(chemin_fichier, pagesize=landscape(A4))
        elements = []
        
        # Titre
        elements.append(Paragraph(titre, self.styles['Title']))
        elements.append(Spacer(1, 20))
        
        # Préparer les données du tableau
        data = [["Jour", "Créneau", "Module", "Salle", "Groupe", "Enseignant"]]
        
        # Trier les séances par jour et créneau
        jours_ordre = {"lundi": 1, "mardi": 2, "mercredi": 3, "jeudi": 4, "vendredi": 5, "samedi": 6}
        seances.sort(key=lambda x: (jours_ordre.get(x.jour, 7), x.creneau_id))
        
        for s in seances:
            module = self.gestionnaire.trouver_module_par_id(s.module_id)
            salle = self.gestionnaire.trouver_salle_par_id(s.salle_id)
            groupe = self.gestionnaire.trouver_groupe_par_id(s.groupe_id)
            enseignant = self.gestionnaire.trouver_enseignant_par_id(s.enseignant_id)
            creneau = self.gestionnaire.trouver_creneau_par_id(s.creneau_id)
            
            nom_enseignant = ""
            if enseignant:
                user = self.gestionnaire.trouver_utilisateur_par_id(enseignant.utilisateur_id)
                if user:
                    nom_enseignant = user.nom_complet
            
            data.append([
                s.jour.capitalize(),
                creneau.label if creneau else s.creneau_id,
                module.nom if module else "",
                salle.nom if salle else "",
                groupe.nom if groupe else "",
                nom_enseignant
            ])
            
        # Créer le tableau
        t = Table(data)
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))
        
        elements.append(t)
        doc.build(elements)

    def exporter_image(self, seances, chemin_fichier):
        """Exporte les séances en Image (PNG)."""
        # Dimensions
        largeur = 1200
        hauteur = 800
        marge = 50
        
        # Créer l'image blanche
        img = Image.new('RGB', (largeur, hauteur), color='white')
        draw = ImageDraw.Draw(img)
        
        # Essayer de charger une police, sinon défaut
        try:
            font_titre = ImageFont.truetype("DejaVuSans-Bold.ttf", 30)
            font_texte = ImageFont.truetype("DejaVuSans.ttf", 12)
        except:
            font_titre = ImageFont.load_default()
            font_texte = ImageFont.load_default()
            
        # Titre
        draw.text((marge, 20), "Emploi du Temps", fill='black', font=font_titre)
        
        # Dessiner la grille simplifiée
        jours = ["lundi", "mardi", "mercredi", "jeudi", "vendredi"]
        creneaux = ["C1", "C2", "C3", "C4"]
        
        largeur_col = (largeur - 2 * marge) / (len(jours) + 1)
        hauteur_lig = (hauteur - 100) / (len(creneaux) + 1)
        
        # En-têtes Jours
        for i, jour in enumerate(jours):
            x = marge + (i + 1) * largeur_col
            y = 80
            draw.rectangle([x, y, x + largeur_col, y + hauteur_lig], outline='black', fill='#E3F2FD')
            draw.text((x + 10, y + 10), jour.capitalize(), fill='black', font=font_texte)
            
        # En-têtes Créneaux
        for j, creneau in enumerate(creneaux):
            x = marge
            y = 80 + (j + 1) * hauteur_lig
            draw.rectangle([x, y, x + largeur_col, y + hauteur_lig], outline='black', fill='#E3F2FD')
            draw.text((x + 10, y + 10), creneau, fill='black', font=font_texte)
            
        # Remplir les séances
        for s in seances:
            if s.jour in jours and s.creneau_id in creneaux:
                col = jours.index(s.jour)
                lig = creneaux.index(s.creneau_id)
                
                x = marge + (col + 1) * largeur_col
                y = 80 + (lig + 1) * hauteur_lig
                
                module = self.gestionnaire.trouver_module_par_id(s.module_id)
                salle = self.gestionnaire.trouver_salle_par_id(s.salle_id)
                
                texte = ""
                if module:
                    texte += module.nom + "\n"
                if salle:
                    texte += salle.nom
                
                draw.rectangle([x, y, x + largeur_col, y + hauteur_lig], outline='black', fill='#F5F5F5')
                draw.text((x + 5, y + 5), texte, fill='black', font=font_texte)
        
        img.save(chemin_fichier)
