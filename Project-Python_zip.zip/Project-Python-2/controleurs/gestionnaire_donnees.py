# -*- coding: utf-8 -*-
"""
GestionnaireDonnees - Gestion des données de l'application
"""

import json
import os
import uuid

from modeles.utilisateur import Utilisateur
from modeles.filiere import Filiere
from modeles.groupe import Groupe
from modeles.enseignant import Enseignant
from modeles.salle import Salle
from modeles.module import Module
from modeles.creneau import Creneau
from modeles.seance import Seance
from modeles.reservation import Reservation


class GestionnaireDonnees:
    """
    Classe gérant toutes les opérations de données.
    """
    
    def __init__(self, dossier_donnees="donnees"):
        """
        Initialise le gestionnaire de données.
        """
        self.dossier = dossier_donnees
        self._creer_dossier_si_necessaire()
    
    def _creer_dossier_si_necessaire(self):
        """Crée le dossier de données s'il n'existe pas."""
        if not os.path.exists(self.dossier):
            os.makedirs(self.dossier)
    
    def _chemin_fichier(self, nom_fichier):
        """Retourne le chemin complet d'un fichier."""
        return os.path.join(self.dossier, nom_fichier)
    
    def _charger_json(self, nom_fichier):
        """Charge un fichier JSON."""
        chemin = self._chemin_fichier(nom_fichier)
        if os.path.exists(chemin):
            with open(chemin, 'r', encoding='utf-8') as f:
                return json.load(f)
        return []
    
    def _sauvegarder_json(self, nom_fichier, donnees):
        """Sauvegarde des données dans un fichier JSON."""
        chemin = self._chemin_fichier(nom_fichier)
        with open(chemin, 'w', encoding='utf-8') as f:
            json.dump(donnees, f, indent=4, ensure_ascii=False)
    
    def generer_id(self, prefixe=""):
        """Génère un identifiant unique."""
        return prefixe + uuid.uuid4().hex[:8].upper()
    
    # ==================== UTILISATEURS ====================
    
    def charger_utilisateurs(self):
        """Charge tous les utilisateurs."""
        donnees = self._charger_json("utilisateurs.json")
        utilisateurs = []
        for d in donnees:
            utilisateurs.append(Utilisateur.depuis_dict(d))
        return utilisateurs
    
    def sauvegarder_utilisateurs(self, utilisateurs):
        """Sauvegarde les utilisateurs."""
        donnees = []
        for u in utilisateurs:
            donnees.append(u.vers_dict())
        self._sauvegarder_json("utilisateurs.json", donnees)
    
    def trouver_utilisateur_par_email(self, email):
        """Trouve un utilisateur par son email."""
        utilisateurs = self.charger_utilisateurs()
        for u in utilisateurs:
            if u.email == email:
                return u
        return None
    
    def trouver_utilisateur_par_id(self, id):
        """Trouve un utilisateur par son ID."""
        utilisateurs = self.charger_utilisateurs()
        for u in utilisateurs:
            if u.id == id:
                return u
        return None
    
    def ajouter_utilisateur(self, utilisateur):
        """Ajoute un utilisateur."""
        utilisateurs = self.charger_utilisateurs()
        utilisateurs.append(utilisateur)
        self.sauvegarder_utilisateurs(utilisateurs)
    
    def authentifier(self, email, mot_de_passe):
        """
        Authentifie un utilisateur.
        Retourne l'utilisateur si succès, None sinon.
        """
        utilisateur = self.trouver_utilisateur_par_email(email)
        if utilisateur and utilisateur.verifier_mot_de_passe(mot_de_passe):
            return utilisateur
        return None
    
    # ==================== FILIERES ====================
    
    def charger_filieres(self):
        """Charge toutes les filières."""
        donnees = self._charger_json("filieres.json")
        filieres = []
        for d in donnees:
            filieres.append(Filiere.depuis_dict(d))
        return filieres
    
    def sauvegarder_filieres(self, filieres):
        """Sauvegarde les filières."""
        donnees = []
        for f in filieres:
            donnees.append(f.vers_dict())
        self._sauvegarder_json("filieres.json", donnees)
    
    def trouver_filiere_par_id(self, id):
        """Trouve une filière par son ID."""
        filieres = self.charger_filieres()
        for f in filieres:
            if f.id == id:
                return f
        return None
    
    def ajouter_filiere(self, filiere):
        """Ajoute une filière."""
        filieres = self.charger_filieres()
        filieres.append(filiere)
        self.sauvegarder_filieres(filieres)
    
    # ==================== GROUPES ====================
    
    def charger_groupes(self):
        """Charge tous les groupes."""
        donnees = self._charger_json("groupes.json")
        groupes = []
        for d in donnees:
            groupes.append(Groupe.depuis_dict(d))
        return groupes
    
    def sauvegarder_groupes(self, groupes):
        """Sauvegarde les groupes."""
        donnees = []
        for g in groupes:
            donnees.append(g.vers_dict())
        self._sauvegarder_json("groupes.json", donnees)
    
    def trouver_groupe_par_id(self, id):
        """Trouve un groupe par son ID."""
        groupes = self.charger_groupes()
        for g in groupes:
            if g.id == id:
                return g
        return None
    
    def trouver_groupes_par_filiere(self, filiere_id):
        """Trouve les groupes d'une filière."""
        groupes = self.charger_groupes()
        resultat = []
        for g in groupes:
            if g.filiere_id == filiere_id:
                resultat.append(g)
        return resultat
    
    def ajouter_groupe(self, groupe):
        """Ajoute un groupe."""
        groupes = self.charger_groupes()
        groupes.append(groupe)
        self.sauvegarder_groupes(groupes)
    
    # ==================== ENSEIGNANTS ====================
    
    def charger_enseignants(self):
        """Charge tous les enseignants."""
        donnees = self._charger_json("enseignants.json")
        enseignants = []
        for d in donnees:
            enseignants.append(Enseignant.depuis_dict(d))
        return enseignants
    
    def sauvegarder_enseignants(self, enseignants):
        """Sauvegarde les enseignants."""
        donnees = []
        for e in enseignants:
            donnees.append(e.vers_dict())
        self._sauvegarder_json("enseignants.json", donnees)
    
    def trouver_enseignant_par_id(self, id):
        """Trouve un enseignant par son ID."""
        enseignants = self.charger_enseignants()
        for e in enseignants:
            if e.id == id:
                return e
        return None
    
    def trouver_enseignant_par_utilisateur(self, utilisateur_id):
        """Trouve un enseignant par son ID utilisateur."""
        enseignants = self.charger_enseignants()
        for e in enseignants:
            if e.utilisateur_id == utilisateur_id:
                return e
        return None
    
    def ajouter_enseignant(self, enseignant):
        """Ajoute un enseignant."""
        enseignants = self.charger_enseignants()
        enseignants.append(enseignant)
        self.sauvegarder_enseignants(enseignants)
    
    # ==================== SALLES ====================
    
    def charger_salles(self):
        """Charge toutes les salles."""
        donnees = self._charger_json("salles.json")
        salles = []
        for d in donnees:
            salles.append(Salle.depuis_dict(d))
        return salles
    
    def sauvegarder_salles(self, salles):
        """Sauvegarde les salles."""
        donnees = []
        for s in salles:
            donnees.append(s.vers_dict())
        self._sauvegarder_json("salles.json", donnees)
    
    def trouver_salle_par_id(self, id):
        """Trouve une salle par son ID."""
        salles = self.charger_salles()
        for s in salles:
            if s.id == id:
                return s
        return None
    
    def ajouter_salle(self, salle):
        """Ajoute une salle."""
        salles = self.charger_salles()
        salles.append(salle)
        self.sauvegarder_salles(salles)
    
    # ==================== MODULES ====================
    
    def charger_modules(self):
        """Charge tous les modules."""
        donnees = self._charger_json("modules.json")
        modules = []
        for d in donnees:
            modules.append(Module.depuis_dict(d))
        return modules
    
    def sauvegarder_modules(self, modules):
        """Sauvegarde les modules."""
        donnees = []
        for m in modules:
            donnees.append(m.vers_dict())
        self._sauvegarder_json("modules.json", donnees)
    
    def trouver_module_par_id(self, id):
        """Trouve un module par son ID."""
        modules = self.charger_modules()
        for m in modules:
            if m.id == id:
                return m
        return None
    
    def trouver_modules_par_filiere(self, filiere_id):
        """Trouve les modules d'une filière."""
        modules = self.charger_modules()
        resultat = []
        for m in modules:
            if m.filiere_id == filiere_id:
                resultat.append(m)
        return resultat
    
    # ==================== CRENEAUX ====================
    
    def charger_creneaux(self):
        """Charge tous les créneaux."""
        donnees = self._charger_json("creneaux.json")
        creneaux = []
        for d in donnees:
            creneaux.append(Creneau.depuis_dict(d))
        return creneaux
    
    def trouver_creneau_par_id(self, id):
        """Trouve un créneau par son ID."""
        creneaux = self.charger_creneaux()
        for c in creneaux:
            if c.id == id:
                return c
        return None
    
    # ==================== SEANCES ====================
    
    def charger_seances(self):
        """Charge toutes les séances."""
        donnees = self._charger_json("seances.json")
        seances = []
        for d in donnees:
            seances.append(Seance.depuis_dict(d))
        return seances
    
    def sauvegarder_seances(self, seances):
        """Sauvegarde les séances."""
        donnees = []
        for s in seances:
            donnees.append(s.vers_dict())
        self._sauvegarder_json("seances.json", donnees)
    
    def trouver_seances_par_groupe(self, groupe_id):
        """Trouve les séances d'un groupe."""
        seances = self.charger_seances()
        resultat = []
        for s in seances:
            if s.groupe_id == groupe_id:
                resultat.append(s)
        return resultat
    
    def trouver_seances_par_enseignant(self, enseignant_id):
        """Trouve les séances d'un enseignant."""
        seances = self.charger_seances()
        resultat = []
        for s in seances:
            if s.enseignant_id == enseignant_id:
                resultat.append(s)
        return resultat
    
    # ==================== RESERVATIONS ====================
    
    def charger_reservations(self):
        """Charge toutes les réservations."""
        donnees = self._charger_json("reservations.json")
        reservations = []
        for d in donnees:
            reservations.append(Reservation.depuis_dict(d))
        return reservations
    
    def sauvegarder_reservations(self, reservations):
        """Sauvegarde les réservations."""
        donnees = []
        for r in reservations:
            donnees.append(r.vers_dict())
        self._sauvegarder_json("reservations.json", donnees)
    
    def trouver_reservations_par_enseignant(self, enseignant_id):
        """Trouve les réservations d'un enseignant."""
        reservations = self.charger_reservations()
        resultat = []
        for r in reservations:
            if r.enseignant_id == enseignant_id:
                resultat.append(r)
        return resultat
    
    def ajouter_reservation(self, reservation):
        """Ajoute une réservation."""
        reservations = self.charger_reservations()
        reservations.append(reservation)
        self.sauvegarder_reservations(reservations)
