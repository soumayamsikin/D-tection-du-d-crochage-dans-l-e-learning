# -*- coding: utf-8 -*-
"""
GenerateurEmploi - Génération automatique des emplois du temps
"""

from modeles.seance import Seance
from controleurs.detecteur_conflits import DetecteurConflits


class GenerateurEmploi:
    """
    Classe de génération automatique des emplois du temps.
    """
    
    JOURS = ["lundi", "mardi", "mercredi", "jeudi", "vendredi"]
    
    def __init__(self, gestionnaire_donnees):
        """
        Initialise le générateur d'emploi du temps.
        """
        self.gestionnaire = gestionnaire_donnees
        self.detecteur = DetecteurConflits(gestionnaire_donnees)
    
    def generer_emploi_temps(self, filiere_id=None, reinitialiser=True):
        """
        Génère un emploi du temps automatiquement.
        Retourne un tuple (liste des séances créées, liste des erreurs).
        """
        erreurs = []
        seances_creees = []
        
        # Charger les données nécessaires
        if reinitialiser:
            seances_existantes = []
        else:
            seances_existantes = self.gestionnaire.charger_seances()
        
        creneaux = self.gestionnaire.charger_creneaux()
        salles = self.gestionnaire.charger_salles()
        
        # Durée d'un créneau (environ 2h)
        DUREE_CRENEAU = 2
        
        # Récupérer les modules à programmer
        if filiere_id:
            modules = self.gestionnaire.trouver_modules_par_filiere(filiere_id)
            groupes = self.gestionnaire.trouver_groupes_par_filiere(filiere_id)
        else:
            modules = self.gestionnaire.charger_modules()
            groupes = self.gestionnaire.charger_groupes()
        
        # Pour chaque module, essayer de placer les séances
        for module in modules:
            # Trouver les groupes concernés par ce module
            groupes_module = []
            for g in groupes:
                if g.filiere_id == module.filiere_id:
                    groupes_module.append(g)
            
            # Calculer le nombre de séances à placer par semaine
            nb_seances_requises = max(1, module.heures_semaine // DUREE_CRENEAU)
            
            for groupe in groupes_module:
                seances_placees = 0
                
                for i in range(nb_seances_requises):
                    resultat = self._placer_seance_module(
                        module, groupe, creneaux, salles, 
                        seances_existantes + seances_creees
                    )
                    
                    if resultat:
                        seances_creees.append(resultat)
                        seances_placees = seances_placees + 1
                
                if seances_placees < nb_seances_requises:
                    erreurs.append(
                        "Module '" + module.nom + "' groupe '" + groupe.nom + "': " +
                        str(seances_placees) + "/" + str(nb_seances_requises) + " séances placées"
                    )
        
        # Sauvegarder les séances
        if seances_creees:
            toutes_seances = seances_existantes + seances_creees
            self.gestionnaire.sauvegarder_seances(toutes_seances)
        
        return seances_creees, erreurs
    
    def _placer_seance_module(self, module, groupe, creneaux, salles, seances_existantes):
        """
        Essaie de placer une séance pour un module et un groupe.
        """
        # Trier les salles par pertinence
        salles_compatibles = self._filtrer_salles_compatibles(salles, module, groupe)
        
        # Essayer chaque combinaison jour/créneau/salle
        meilleures_options = []
        
        for jour in self.JOURS:
            for creneau in creneaux:
                for salle in salles_compatibles:
                    score = self._evaluer_placement(
                        module, groupe, jour, creneau, salle,
                        seances_existantes
                    )
                    if score is not None:
                        meilleures_options.append({
                            'jour': jour,
                            'creneau': creneau,
                            'salle': salle,
                            'score': score
                        })
        
        # Choisir la meilleure option
        if meilleures_options:
            # Trier par score décroissant
            meilleures_options.sort(key=lambda x: x['score'], reverse=True)
            meilleure = meilleures_options[0]
            
            # Créer la séance
            seance = Seance(
                id=self.gestionnaire.generer_id("SEA"),
                module_id=module.id,
                salle_id=meilleure['salle'].id,
                creneau_id=meilleure['creneau'].id,
                jour=meilleure['jour'],
                groupe_id=groupe.id,
                enseignant_id=module.enseignant_id
            )
            return seance
        
        return None
    
    def _filtrer_salles_compatibles(self, salles, module, groupe):
        """
        Filtre les salles compatibles pour un module et un groupe.
        """
        compatibles = []
        compatibles_partiel = []
        type_requis = module.type_salle_requis
        
        for salle in salles:
            # Vérifier le type de salle
            if type_requis == "amphi" and salle.type != "amphi":
                continue
            if type_requis == "tp" and salle.type != "tp":
                continue
            if type_requis == "td" and salle.type not in ["td", "amphi"]:
                continue
            
            # Vérifier la capacité
            capacite_requise = groupe.nombre_etudiants
            if salle.capacite < capacite_requise * 0.9:
                continue
            
            # Vérifier les équipements
            if module.equipements_requis and salle.a_tous_equipements(module.equipements_requis):
                compatibles.append(salle)
            else:
                compatibles_partiel.append(salle)
        
        # Si pas de salles avec tous les équipements, utiliser les partielles
        if not compatibles:
            compatibles = compatibles_partiel
        
        # Trier par capacité
        compatibles.sort(key=lambda s: abs(s.capacite - groupe.nombre_etudiants))
        
        return compatibles
    
    def _evaluer_placement(self, module, groupe, jour, creneau, salle, seances_existantes):
        """
        Évalue un placement potentiel.
        Retourne un score (plus élevé = meilleur), None si impossible.
        """
        # Vérifier la disponibilité de la salle
        if not self.detecteur.salle_est_libre(salle.id, jour, creneau.id, seances_existantes):
            return None
        
        # Vérifier la disponibilité de l'enseignant
        if not self.detecteur.enseignant_est_libre(module.enseignant_id, jour, creneau.id, seances_existantes):
            return None
        
        # Vérifier la disponibilité du groupe
        if not self.detecteur.groupe_est_libre(groupe.id, jour, creneau.id, seances_existantes):
            return None
        
        # Calculer le score
        score = 100.0
        
        # Préférer les salles de taille adaptée
        ratio_capacite = groupe.nombre_etudiants / salle.capacite
        if ratio_capacite >= 0.7 and ratio_capacite <= 1.0:
            score = score + 20
        elif ratio_capacite < 0.5:
            score = score - 10
        
        # Préférer les créneaux du matin
        if creneau.id in ["C1", "C2"]:
            score = score + 5
        
        # Éviter trop de cours le même jour
        cours_ce_jour = 0
        for s in seances_existantes:
            if s.groupe_id == groupe.id and s.jour == jour:
                cours_ce_jour = cours_ce_jour + 1
        score = score - cours_ce_jour * 5
        
        return score
    
    def supprimer_toutes_seances(self, filiere_id=None):
        """
        Supprime toutes les séances.
        """
        seances = self.gestionnaire.charger_seances()
        
        if filiere_id:
            groupes = self.gestionnaire.trouver_groupes_par_filiere(filiere_id)
            groupe_ids = []
            for g in groupes:
                groupe_ids.append(g.id)
            
            seances_a_garder = []
            for s in seances:
                if s.groupe_id not in groupe_ids:
                    seances_a_garder.append(s)
            
            nb_supprimees = len(seances) - len(seances_a_garder)
            self.gestionnaire.sauvegarder_seances(seances_a_garder)
        else:
            nb_supprimees = len(seances)
            self.gestionnaire.sauvegarder_seances([])
        
    def obtenir_statistiques(self):
        """
        Calcule et retourne les statistiques d'occupation.
        """
        seances = self.gestionnaire.charger_seances()
        salles = self.gestionnaire.charger_salles()
        creneaux = self.gestionnaire.charger_creneaux()
        
        # Initialisation
        stats = {
            'total_seances': len(seances),
            'total_salles': len(salles),
            'taux_occupation_global': 0,
            'occupation_par_salle': {},
            'creneaux_surcharges': []
        }
        
        # Calcul occupation par salle
        total_capacite_creneaux = len(salles) * len(creneaux) * len(self.JOURS)
        if total_capacite_creneaux > 0:
            stats['taux_occupation_global'] = round((len(seances) / total_capacite_creneaux) * 100, 1)
            
        max_seances_par_salle = len(creneaux) * len(self.JOURS)
        
        for salle in salles:
            seances_salle = 0
            for s in seances:
                if s.salle_id == salle.id:
                    seances_salle = seances_salle + 1
            
            taux = 0
            if max_seances_par_salle > 0:
                taux = round((seances_salle / max_seances_par_salle) * 100, 1)
                
            stats['occupation_par_salle'][salle.nom] = {
                'taux': taux,
                'seances': seances_salle,
                'max': max_seances_par_salle
            }
            
        # Calcul créneaux surchargés
        compteur_creneaux = {}
        for s in seances:
            cle = s.jour.capitalize() + " " + s.creneau_id
            if cle in compteur_creneaux:
                compteur_creneaux[cle] = compteur_creneaux[cle] + 1
            else:
                compteur_creneaux[cle] = 1
                
        # Trier et prendre les top 5
        creneaux_tries = sorted(compteur_creneaux.items(), key=lambda x: x[1], reverse=True)
        stats['creneaux_surcharges'] = creneaux_tries[:5]
        
        return stats
