# -*- coding: utf-8 -*-
"""
Constantes - Constantes globales de l'application
"""

# Jours de la semaine
JOURS_SEMAINE = ["lundi", "mardi", "mercredi", "jeudi", "vendredi"]

# Labels des jours pour l'affichage
JOURS_LABELS = {
    "lundi": "Lundi",
    "mardi": "Mardi",
    "mercredi": "Mercredi",
    "jeudi": "Jeudi",
    "vendredi": "Vendredi"
}

# Types de salles
TYPES_SALLES = {
    "amphi": "Amphithéâtre",
    "td": "Salle TD",
    "tp": "Salle TP"
}

# Types de séances
TYPES_SEANCES = {
    "CM": "Cours Magistral",
    "TD": "Travaux Dirigés",
    "TP": "Travaux Pratiques"
}

# Niveaux d'études
NIVEAUX = ["L1", "L2", "L3", "M1", "M2"]

# Couleurs de l'interface
COULEURS = {
    "primaire": "#1E88E5",
    "primaire_hover": "#1565C0",
    "secondaire": "#43A047",
    "secondaire_hover": "#2E7D32",
    "danger": "#E53935",
    "danger_hover": "#C62828",
    "warning": "#FB8C00",
    "warning_hover": "#EF6C00",
    "accent": "#8E24AA",
    "accent_hover": "#7B1FA2",
    "fond": "#F5F5F5",
    "fond_sombre": "#1a1a2e",
    "carte": "#FFFFFF",
    "texte": "#212121",
    "texte_secondaire": "#757575",
    "bordure": "#E0E0E0"
}

# Couleurs pour les types de séances (emploi du temps)
COULEURS_SEANCES = {
    "CM": "#2196F3",  # Bleu
    "TD": "#4CAF50",  # Vert
    "TP": "#FF9800"   # Orange
}

# Taille de la fenêtre
TAILLE_FENETRE = "1200x700"
TAILLE_MIN = (1000, 600)

# Liste des équipements disponibles
EQUIPEMENTS = [
    "projecteur",
    "tableau_blanc",
    "ordinateurs",
    "micro",
    "climatisation",
    "equipement_labo"
]

# Labels des équipements
EQUIPEMENTS_LABELS = {
    "projecteur": "Projecteur",
    "tableau_blanc": "Tableau blanc",
    "ordinateurs": "Ordinateurs",
    "micro": "Micro",
    "climatisation": "Climatisation",
    "equipement_labo": "Équipement labo"
}
