# -*- coding: utf-8 -*-
"""
TableauEnseignant - Tableau de bord de l'enseignant
"""

import customtkinter as ctk
from tkinter import messagebox
from controleurs.gestionnaire_donnees import GestionnaireDonnees
from controleurs.detecteur_conflits import DetecteurConflits
from modeles.reservation import Reservation
from utilitaires.constantes import COULEURS, JOURS_LABELS, JOURS_SEMAINE, COULEURS_SEANCES


class TableauEnseignant(ctk.CTkFrame):
    """Tableau de bord de l'enseignant."""
    
    def __init__(self, parent, application):
        super().__init__(parent, fg_color=COULEURS["fond"])
        self.application = application
        self.gestionnaire = application.gestionnaire
        self.detecteur = DetecteurConflits(self.gestionnaire)
        
        utilisateur = application.utilisateur_connecte
        self.enseignant = self.gestionnaire.trouver_enseignant_par_utilisateur(utilisateur.id)
        self.menu_actif = "emploi_temps"
        
        self._creer_interface()
    
    def _creer_interface(self):
        self._creer_entete()
        corps = ctk.CTkFrame(self, fg_color="transparent")
        corps.pack(fill="both", expand=True, padx=20, pady=10)
        self._creer_menu_lateral(corps)
        self.zone_contenu = ctk.CTkFrame(corps, fg_color=COULEURS["carte"], corner_radius=15)
        self.zone_contenu.pack(side="left", fill="both", expand=True, padx=(10, 0))
        self._afficher_emploi_temps()
    
    def _creer_entete(self):
        entete = ctk.CTkFrame(self, fg_color=COULEURS["secondaire"], height=60)
        entete.pack(fill="x")
        entete.pack_propagate(False)
        
        contenu = ctk.CTkFrame(entete, fg_color="transparent")
        contenu.pack(fill="both", expand=True, padx=20)
        
        ctk.CTkLabel(contenu, text="👨‍Espace Enseignant", 
                     font=ctk.CTkFont(size=18, weight="bold"), text_color="white").pack(side="left", pady=15)
        
        frame_user = ctk.CTkFrame(contenu, fg_color="transparent")
        frame_user.pack(side="right", pady=10)
        
        ctk.CTkLabel(frame_user, text=f"{self.application.utilisateur_connecte.nom_complet}",
                     font=ctk.CTkFont(size=13), text_color="white").pack(side="left", padx=10)
        
        ctk.CTkButton(frame_user, text="Déconnexion", width=100, height=30, fg_color="transparent",
                      border_width=1, border_color="white", hover_color=COULEURS["secondaire_hover"],
                      command=self.application.deconnecter).pack(side="left")
    
    def _creer_menu_lateral(self, parent):
        menu = ctk.CTkFrame(parent, fg_color=COULEURS["carte"], width=200, corner_radius=15)
        menu.pack(side="left", fill="y")
        menu.pack_propagate(False)
        
        ctk.CTkLabel(menu, text="Menu", font=ctk.CTkFont(size=16, weight="bold")).pack(pady=20)
        
        options = [
            ("Mon emploi du temps", "emploi_temps", self._afficher_emploi_temps),
            ("Mes réservations", "reservations", self._afficher_reservations),
            ("Rechercher salle", "recherche", self._afficher_recherche_salle),
            ("Indisponibilités", "indisponibilites", self._afficher_indisponibilites),
        ]
        
        self.boutons_menu = {}
        for texte, id_menu, commande in options:
            btn = ctk.CTkButton(menu, text=texte, width=180, height=40, anchor="w",
                fg_color=COULEURS["secondaire"] if id_menu == self.menu_actif else "transparent",
                text_color="white" if id_menu == self.menu_actif else COULEURS["texte"],
                hover_color=COULEURS["secondaire_hover"],
                command=lambda cmd=commande, id=id_menu: self._changer_menu(id, cmd))
            btn.pack(pady=3, padx=10)
            self.boutons_menu[id_menu] = btn
    
    def _changer_menu(self, id_menu, commande):
        for id_btn, btn in self.boutons_menu.items():
            if id_btn == id_menu:
                btn.configure(fg_color=COULEURS["secondaire"], text_color="white")
            else:
                btn.configure(fg_color="transparent", text_color=COULEURS["texte"])
        self.menu_actif = id_menu
        commande()
    
    def _vider_contenu(self):
        for widget in self.zone_contenu.winfo_children():
            widget.destroy()
    
    def _afficher_emploi_temps(self):
        self._vider_contenu()
        ctk.CTkLabel(self.zone_contenu, text="Mon Emploi du Temps",
                     font=ctk.CTkFont(size=18, weight="bold")).pack(padx=20, pady=15, anchor="w")
        
        frame_grille = ctk.CTkScrollableFrame(self.zone_contenu, fg_color="transparent")
        frame_grille.pack(fill="both", expand=True, padx=20, pady=10)
        
        creneaux = self.gestionnaire.charger_creneaux()
        seances = self.gestionnaire.trouver_seances_par_enseignant(self.enseignant.id) if self.enseignant else []
        
        ctk.CTkLabel(frame_grille, text="", width=100).grid(row=0, column=0, padx=2, pady=2)
        for col, jour in enumerate(JOURS_SEMAINE):
            ctk.CTkLabel(frame_grille, text=JOURS_LABELS.get(jour, jour),
                font=ctk.CTkFont(size=13, weight="bold"), fg_color=COULEURS["secondaire"],
                text_color="white", corner_radius=5, width=140, height=35
            ).grid(row=0, column=col+1, padx=2, pady=2, sticky="ew")
        
        for row, creneau in enumerate(creneaux):
            ctk.CTkLabel(frame_grille, text=creneau.label, fg_color="#E8F5E9",
                         corner_radius=5, width=100, height=70).grid(row=row+1, column=0, padx=2, pady=2)
            
            for col, jour in enumerate(JOURS_SEMAINE):
                seances_cellule = [s for s in seances if s.jour == jour and s.creneau_id == creneau.id]
                cellule = ctk.CTkFrame(frame_grille, fg_color=COULEURS["fond"], corner_radius=5, width=140, height=70)
                cellule.grid(row=row+1, column=col+1, padx=2, pady=2, sticky="nsew")
                cellule.pack_propagate(False)
                
                if seances_cellule:
                    seance = seances_cellule[0]
                    module = self.gestionnaire.trouver_module_par_id(seance.module_id)
                    salle = self.gestionnaire.trouver_salle_par_id(seance.salle_id)
                    if module:
                        couleur = COULEURS_SEANCES.get(module.type_seance, COULEURS["secondaire"])
                        info = ctk.CTkFrame(cellule, fg_color=couleur, corner_radius=5)
                        info.pack(fill="both", expand=True, padx=3, pady=3)
                        ctk.CTkLabel(info, text=module.nom[:18], font=ctk.CTkFont(size=10, weight="bold"),
                                     text_color="white").pack(pady=(8,2))
                        ctk.CTkLabel(info, text=f"{salle.nom if salle else '?'}",
                                     font=ctk.CTkFont(size=9), text_color="white").pack()
    
    def _afficher_reservations(self):
        self._vider_contenu()
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        ctk.CTkLabel(entete, text="Mes Réservations", font=ctk.CTkFont(size=18, weight="bold")).pack(side="left")
        ctk.CTkButton(entete, text="Nouvelle", fg_color=COULEURS["secondaire"],
                      command=self._formulaire_reservation).pack(side="right")
        
        frame_liste = ctk.CTkScrollableFrame(self.zone_contenu, fg_color="transparent")
        frame_liste.pack(fill="both", expand=True, padx=20, pady=10)
        
        reservations = self.gestionnaire.trouver_reservations_par_enseignant(self.enseignant.id) if self.enseignant else []
        
        if not reservations:
            ctk.CTkLabel(frame_liste, text="Aucune réservation", text_color=COULEURS["texte_secondaire"]).pack(pady=50)
            return
        
        for r in reservations:
            salle = self.gestionnaire.trouver_salle_par_id(r.salle_id)
            creneau = self.gestionnaire.trouver_creneau_par_id(r.creneau_id)
            carte = ctk.CTkFrame(frame_liste, fg_color=COULEURS["fond"], corner_radius=10)
            carte.pack(fill="x", pady=5, padx=5)
            ctk.CTkLabel(carte, text=f"{salle.nom if salle else '?'} - {r.jour} {r.date}",
                         font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w", padx=10, pady=5)
            ctk.CTkLabel(carte, text=f"{creneau.label if creneau else '?'} | {r.motif}",
                         font=ctk.CTkFont(size=11), text_color=COULEURS["texte_secondaire"]).pack(anchor="w", padx=10)
            couleurs = {"en_attente": COULEURS["warning"], "acceptee": COULEURS["secondaire"], "refusee": COULEURS["danger"]}
            ctk.CTkLabel(carte, text=r.statut_affichage, fg_color=couleurs.get(r.statut, COULEURS["primaire"]),
                         text_color="white", corner_radius=10, padx=10).pack(anchor="e", padx=10, pady=5)
    
    def _formulaire_reservation(self):
        self._vider_contenu()
        ctk.CTkButton(self.zone_contenu, text="Retour", fg_color="transparent",
                      command=self._afficher_reservations).pack(anchor="w", padx=20, pady=10)
        ctk.CTkLabel(self.zone_contenu, text="Nouvelle Réservation",
                     font=ctk.CTkFont(size=18, weight="bold")).pack(anchor="w", padx=20)
        
        frame = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        frame.pack(padx=40, pady=20, anchor="w")
        
        salles = self.gestionnaire.charger_salles()
        creneaux = self.gestionnaire.charger_creneaux()
        
        ctk.CTkLabel(frame, text="Salle:").pack(anchor="w")
        self.var_salle = ctk.StringVar()
        ctk.CTkComboBox(frame, values=[s.nom for s in salles], variable=self.var_salle, width=250).pack(anchor="w", pady=(0,10))
        
        ctk.CTkLabel(frame, text="Jour:").pack(anchor="w")
        self.var_jour = ctk.StringVar()
        ctk.CTkComboBox(frame, values=[JOURS_LABELS[j] for j in JOURS_SEMAINE], variable=self.var_jour, width=250).pack(anchor="w", pady=(0,10))
        
        ctk.CTkLabel(frame, text="Créneau:").pack(anchor="w")
        self.var_creneau = ctk.StringVar()
        ctk.CTkComboBox(frame, values=[c.label for c in creneaux], variable=self.var_creneau, width=250).pack(anchor="w", pady=(0,10))
        
        ctk.CTkLabel(frame, text="Date (YYYY-MM-DD):").pack(anchor="w")
        self.entry_date = ctk.CTkEntry(frame, width=250)
        self.entry_date.pack(anchor="w", pady=(0,10))
        
        ctk.CTkLabel(frame, text="Motif:").pack(anchor="w")
        self.entry_motif = ctk.CTkEntry(frame, width=250)
        self.entry_motif.pack(anchor="w", pady=(0,15))
        
        ctk.CTkButton(frame, text="Soumettre", fg_color=COULEURS["secondaire"],
                      command=self._soumettre_reservation).pack(anchor="w")
    
    def _soumettre_reservation(self):
        salles = self.gestionnaire.charger_salles()
        creneaux = self.gestionnaire.charger_creneaux()
        salle = next((s for s in salles if s.nom == self.var_salle.get()), None)
        creneau = next((c for c in creneaux if c.label == self.var_creneau.get()), None)
        jour = next((j for j, l in JOURS_LABELS.items() if l == self.var_jour.get()), None)
        
        if not all([salle, creneau, jour, self.entry_date.get(), self.entry_motif.get()]):
            messagebox.showerror("Erreur", "Remplissez tous les champs")
            return
        
        reservation = Reservation(
            id=self.gestionnaire.generer_id("RES"), enseignant_id=self.enseignant.id,
            salle_id=salle.id, creneau_id=creneau.id, jour=jour,
            date=self.entry_date.get(), motif=self.entry_motif.get())
        self.gestionnaire.ajouter_reservation(reservation)
        messagebox.showinfo("Succès", "Demande soumise")
        self._afficher_reservations()
    
    def _afficher_recherche_salle(self):
        self._vider_contenu()
        ctk.CTkLabel(self.zone_contenu, text="Rechercher Salle Libre",
                     font=ctk.CTkFont(size=18, weight="bold")).pack(anchor="w", padx=20, pady=15)
        
        frame = ctk.CTkFrame(self.zone_contenu, fg_color=COULEURS["fond"], corner_radius=10)
        frame.pack(fill="x", padx=20, pady=10)
        inputs = ctk.CTkFrame(frame, fg_color="transparent")
        inputs.pack(pady=15)
        
        ctk.CTkLabel(inputs, text="Jour:").pack(side="left", padx=5)
        self.var_rech_jour = ctk.StringVar(value="Tous")
        ctk.CTkComboBox(inputs, values=["Tous"] + [JOURS_LABELS[j] for j in JOURS_SEMAINE],
                        variable=self.var_rech_jour, width=120).pack(side="left", padx=5)
        
        ctk.CTkButton(inputs, text="Rechercher", fg_color=COULEURS["secondaire"],
                      command=self._executer_recherche).pack(side="left", padx=20)
        
        self.frame_resultats = ctk.CTkScrollableFrame(self.zone_contenu, fg_color="transparent")
        self.frame_resultats.pack(fill="both", expand=True, padx=20, pady=10)
    
    def _executer_recherche(self):
        for w in self.frame_resultats.winfo_children(): w.destroy()
        jour_label = self.var_rech_jour.get()
        jours = JOURS_SEMAINE if jour_label == "Tous" else [j for j, l in JOURS_LABELS.items() if l == jour_label]
        
        salles = self.gestionnaire.charger_salles()
        creneaux = self.gestionnaire.charger_creneaux()
        seances = self.gestionnaire.charger_seances()
        
        resultats = []
        for salle in salles:
            for jour in jours:
                for creneau in creneaux:
                    if self.detecteur.salle_est_libre(salle.id, jour, creneau.id, seances):
                        resultats.append(f"{salle.nom} - {JOURS_LABELS[jour]} {creneau.label}")
        
        if resultats:
            for r in resultats[:20]:
                ctk.CTkLabel(self.frame_resultats, text=f"{r}", anchor="w").pack(anchor="w", pady=2)
        else:
            ctk.CTkLabel(self.frame_resultats, text="Aucun créneau libre trouvé").pack(pady=20)
    
    def _afficher_indisponibilites(self):
        self._vider_contenu()
        
        # En-tête
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        
        ctk.CTkLabel(entete, text="Mes Indisponibilités",
                     font=ctk.CTkFont(size=18, weight="bold")).pack(side="left")
        
        ctk.CTkButton(entete, text="Signaler une indisponibilité", 
                      fg_color=COULEURS["secondaire"], hover_color=COULEURS["secondaire_hover"],
                      command=self._formulaire_indisponibilite).pack(side="right")
        
        frame = ctk.CTkScrollableFrame(self.zone_contenu, fg_color="transparent")
        frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        if not self.enseignant or not self.enseignant.indisponibilites:
            ctk.CTkLabel(frame, text="Aucune indisponibilité déclarée",
                         font=ctk.CTkFont(size=14), text_color=COULEURS["texte_secondaire"]).pack(pady=50)
            return
        
        for i, indispo in enumerate(self.enseignant.indisponibilites):
            creneau = self.gestionnaire.trouver_creneau_par_id(indispo.get('creneau_id'))
            jour = indispo.get('jour', '?')
            motif = indispo.get('motif', '')
            
            carte = ctk.CTkFrame(frame, fg_color=COULEURS["fond"], corner_radius=10)
            carte.pack(fill="x", pady=5)
            
            contenu = ctk.CTkFrame(carte, fg_color="transparent")
            contenu.pack(fill="x", padx=15, pady=10)
            
            ctk.CTkLabel(contenu, text=f"{JOURS_LABELS.get(jour, jour)} - {creneau.label if creneau else '?'}",
                         font=ctk.CTkFont(size=13, weight="bold")).pack(side="left")
            
            if motif:
                ctk.CTkLabel(contenu, text=f"{motif}", font=ctk.CTkFont(size=12),
                             text_color=COULEURS["texte_secondaire"]).pack(side="left", padx=20)
            
            ctk.CTkButton(contenu, text="🗑️", width=35, height=30,
                          fg_color=COULEURS["danger"], hover_color=COULEURS["danger_hover"],
                          command=lambda j=jour, c=indispo.get('creneau_id'): self._supprimer_indisponibilite(j, c)
                          ).pack(side="right")
    
    def _formulaire_indisponibilite(self):
        """Affiche le formulaire pour signaler une indisponibilité."""
        self._vider_contenu()
        
        ctk.CTkButton(self.zone_contenu, text="Retour", fg_color="transparent",
                      text_color=COULEURS["texte"], command=self._afficher_indisponibilites
                      ).pack(anchor="w", padx=20, pady=10)
        
        ctk.CTkLabel(self.zone_contenu, text="Signaler une Indisponibilité",
                     font=ctk.CTkFont(size=18, weight="bold")).pack(anchor="w", padx=20)
        
        frame = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        frame.pack(padx=40, pady=20, anchor="w")
        
        # Jour
        ctk.CTkLabel(frame, text="Jour *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.var_indispo_jour = ctk.StringVar()
        ctk.CTkComboBox(frame, values=[JOURS_LABELS[j] for j in JOURS_SEMAINE],
                        variable=self.var_indispo_jour, width=300).pack(anchor="w", pady=(0, 15))
        
        # Créneau
        ctk.CTkLabel(frame, text="Créneau *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        creneaux = self.gestionnaire.charger_creneaux()
        self.var_indispo_creneau = ctk.StringVar()
        ctk.CTkComboBox(frame, values=[c.label for c in creneaux],
                        variable=self.var_indispo_creneau, width=300).pack(anchor="w", pady=(0, 15))
        
        # Motif
        ctk.CTkLabel(frame, text="Motif (optionnel)", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_indispo_motif = ctk.CTkEntry(frame, width=300, 
                                                 placeholder_text="Ex: Réunion, Congé, RDV médical...")
        self.entry_indispo_motif.pack(anchor="w", pady=(0, 20))
        
        ctk.CTkButton(frame, text="Enregistrer l'indisponibilité", 
                      fg_color=COULEURS["secondaire"], hover_color=COULEURS["secondaire_hover"],
                      command=self._ajouter_indisponibilite).pack(anchor="w")
    
    def _ajouter_indisponibilite(self):
        """Ajoute une nouvelle indisponibilité."""
        if not self.enseignant:
            messagebox.showerror("Erreur", "Enseignant non trouvé")
            return
        
        jour_label = self.var_indispo_jour.get()
        creneau_label = self.var_indispo_creneau.get()
        motif = self.entry_indispo_motif.get().strip()
        
        if not jour_label or not creneau_label:
            messagebox.showerror("Erreur", "Veuillez sélectionner un jour et un créneau")
            return
        
        # Trouver le jour et le créneau
        jour = next((j for j, l in JOURS_LABELS.items() if l == jour_label), None)
        creneaux = self.gestionnaire.charger_creneaux()
        creneau = next((c for c in creneaux if c.label == creneau_label), None)
        
        if not jour or not creneau:
            messagebox.showerror("Erreur", "Données invalides")
            return
        
        # Vérifier si l'indisponibilité existe déjà
        for indispo in self.enseignant.indisponibilites:
            if indispo.get('jour') == jour and indispo.get('creneau_id') == creneau.id:
                messagebox.showwarning("Attention", "Cette indisponibilité existe déjà")
                return
        
        # Ajouter l'indisponibilité
        self.enseignant.ajouter_indisponibilite(jour, creneau.id, motif)
        
        # Sauvegarder
        enseignants = self.gestionnaire.charger_enseignants()
        for i, e in enumerate(enseignants):
            if e.id == self.enseignant.id:
                enseignants[i] = self.enseignant
                break
        self.gestionnaire.sauvegarder_enseignants(enseignants)
        
        messagebox.showinfo("Succès", "Indisponibilité enregistrée")
        self._afficher_indisponibilites()
    
    def _supprimer_indisponibilite(self, jour, creneau_id):
        """Supprime une indisponibilité."""
        if messagebox.askyesno("Confirmation", "Voulez-vous supprimer cette indisponibilité ?"):
            self.enseignant.supprimer_indisponibilite(jour, creneau_id)
            
            enseignants = self.gestionnaire.charger_enseignants()
            for i, e in enumerate(enseignants):
                if e.id == self.enseignant.id:
                    enseignants[i] = self.enseignant
                    break
            self.gestionnaire.sauvegarder_enseignants(enseignants)
            
            self._afficher_indisponibilites()
