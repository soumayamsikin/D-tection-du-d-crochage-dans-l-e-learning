# -*- coding: utf-8 -*-
"""
TableauEtudiant - Tableau de bord de l'étudiant
"""

import customtkinter as ctk
from controleurs.gestionnaire_donnees import GestionnaireDonnees
from controleurs.detecteur_conflits import DetecteurConflits
from utilitaires.constantes import COULEURS, JOURS_LABELS, JOURS_SEMAINE, COULEURS_SEANCES


class TableauEtudiant(ctk.CTkFrame):
    """Tableau de bord de l'étudiant."""
    
    def __init__(self, parent, application):
        super().__init__(parent, fg_color=COULEURS["fond"])
        self.application = application
        self.gestionnaire = application.gestionnaire
        self.detecteur = DetecteurConflits(self.gestionnaire)
        
        self.utilisateur = application.utilisateur_connecte
        self.menu_actif = "emploi_temps"
        
        self._creer_interface()
    
    def _creer_interface(self):
        self._creer_entete()
        corps = ctk.CTkFrame(self, fg_color="transparent")
        corps.pack(fill="both", expand=True, padx=20, pady=10)
        self._creer_menu_lateral(corps)
        self.zone_contenu = ctk.CTkFrame(corps, fg_color=COULEURS["carte"], corner_radius=15)
        self.zone_contenu.pack(side="left", fill="both", expand=True, padx=(10, 0))
        self._afficher_emploi_temps()
    
    def _creer_entete(self):
        entete = ctk.CTkFrame(self, fg_color="#9C27B0", height=60)
        entete.pack(fill="x")
        entete.pack_propagate(False)
        
        contenu = ctk.CTkFrame(entete, fg_color="transparent")
        contenu.pack(fill="both", expand=True, padx=20)
        
        ctk.CTkLabel(contenu, text="Espace Étudiant",
                     font=ctk.CTkFont(size=18, weight="bold"), text_color="white").pack(side="left", pady=15)
        
        frame_user = ctk.CTkFrame(contenu, fg_color="transparent")
        frame_user.pack(side="right", pady=10)
        
        # Afficher filière et groupe
        filiere = self.gestionnaire.trouver_filiere_par_id(self.utilisateur.filiere_id)
        groupe = self.gestionnaire.trouver_groupe_par_id(self.utilisateur.groupe_id)
        
        info_text = f"{self.utilisateur.nom_complet}"
        if filiere:
            info_text += f" | {filiere.nom}"
        if groupe:
            info_text += f" - {groupe.nom}"
        
        ctk.CTkLabel(frame_user, text=info_text, font=ctk.CTkFont(size=13),
                     text_color="white").pack(side="left", padx=10)
        
        ctk.CTkButton(frame_user, text="Déconnexion", width=100, height=30, fg_color="transparent",
                      border_width=1, border_color="white", hover_color="#7B1FA2",
                      command=self.application.deconnecter).pack(side="left")
    
    def _creer_menu_lateral(self, parent):
        menu = ctk.CTkFrame(parent, fg_color=COULEURS["carte"], width=200, corner_radius=15)
        menu.pack(side="left", fill="y")
        menu.pack_propagate(False)
        
        ctk.CTkLabel(menu, text="Menu", font=ctk.CTkFont(size=16, weight="bold")).pack(pady=20)
        
        options = [
            ("Mon emploi du temps", "emploi_temps", self._afficher_emploi_temps),
            ("Rechercher salle", "recherche", self._afficher_recherche_salle),
        ]
        
        self.boutons_menu = {}
        for texte, id_menu, commande in options:
            btn = ctk.CTkButton(menu, text=texte, width=180, height=40, anchor="w",
                fg_color="#9C27B0" if id_menu == self.menu_actif else "transparent",
                text_color="white" if id_menu == self.menu_actif else COULEURS["texte"],
                hover_color="#7B1FA2",
                command=lambda cmd=commande, id=id_menu: self._changer_menu(id, cmd))
            btn.pack(pady=3, padx=10)
            self.boutons_menu[id_menu] = btn
    
    def _changer_menu(self, id_menu, commande):
        for id_btn, btn in self.boutons_menu.items():
            if id_btn == id_menu:
                btn.configure(fg_color="#9C27B0", text_color="white")
            else:
                btn.configure(fg_color="transparent", text_color=COULEURS["texte"])
        self.menu_actif = id_menu
        commande()
    
    def _vider_contenu(self):
        for widget in self.zone_contenu.winfo_children():
            widget.destroy()
    
    def _afficher_emploi_temps(self):
        self._vider_contenu()
        
        # En-tête
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        
        ctk.CTkLabel(entete, text="Mon Emploi du Temps",
                     font=ctk.CTkFont(size=18, weight="bold")).pack(side="left")
        
        # Initialiser les variables pour _afficher_grille
        self.var_filiere = ctk.StringVar()
        self.var_groupe = ctk.StringVar()
        
        filiere = self.gestionnaire.trouver_filiere_par_id(self.utilisateur.filiere_id)
        groupe = self.gestionnaire.trouver_groupe_par_id(self.utilisateur.groupe_id)
        
        if filiere:
            self.var_filiere.set(filiere.nom_complet)
        if groupe:
            self.var_groupe.set(groupe.nom)
            
        # Afficher les infos fixes
        info_frame = ctk.CTkFrame(entete, fg_color="transparent")
        info_frame.pack(side="right")
        
        if filiere and groupe:
            ctk.CTkLabel(info_frame, text=f"Filière: {filiere.nom}", 
                         font=ctk.CTkFont(weight="bold"), text_color="black").pack(side="left", padx=10)
            ctk.CTkLabel(info_frame, text=f"Groupe: {groupe.nom}", 
                         font=ctk.CTkFont(weight="bold"), text_color="black").pack(side="left", padx=10)
        else:
            ctk.CTkLabel(info_frame, text="Aucune affectation", 
                         text_color=COULEURS["danger"]).pack(side="left")
        
        # Grille
        self.frame_grille = ctk.CTkScrollableFrame(self.zone_contenu, fg_color="transparent")
        self.frame_grille.pack(fill="both", expand=True, padx=20, pady=10)
        
        self._afficher_grille()
    
    def _afficher_grille(self):
        """Affiche la grille de l'emploi du temps."""
        # Vérifier que frame_grille existe
        if not hasattr(self, 'frame_grille'):
            return
        
        # Vider la grille
        for widget in self.frame_grille.winfo_children():
            widget.destroy()
        
        # Récupérer le groupe de l'étudiant
        groupe_id = self.utilisateur.groupe_id
        
        if not groupe_id:
            ctk.CTkLabel(self.frame_grille, text="Vous n'êtes affecté à aucun groupe.",
                         font=ctk.CTkFont(size=14), text_color=COULEURS["danger"]).pack(pady=50)
            return
            
        groupe = self.gestionnaire.trouver_groupe_par_id(groupe_id)
        
        if not groupe:
            ctk.CTkLabel(self.frame_grille, text="Groupe introuvable.",
                         font=ctk.CTkFont(size=14), text_color=COULEURS["danger"]).pack(pady=50)
            return
        
        # Charger les données
        creneaux = self.gestionnaire.charger_creneaux()
        seances = self.gestionnaire.trouver_seances_par_groupe(groupe.id)
        
        # En-tête des jours
        ctk.CTkLabel(self.frame_grille, text="", width=100).grid(row=0, column=0, padx=2, pady=2)
        for col, jour in enumerate(JOURS_SEMAINE):
            ctk.CTkLabel(self.frame_grille, text=JOURS_LABELS.get(jour, jour),
                font=ctk.CTkFont(size=13, weight="bold"), fg_color="#9C27B0",
                text_color="white", corner_radius=5, width=140, height=35
            ).grid(row=0, column=col+1, padx=2, pady=2, sticky="ew")
        
        # Lignes des créneaux
        for row, creneau in enumerate(creneaux):
            ctk.CTkLabel(self.frame_grille, text=creneau.label, fg_color="#F3E5F5",
                         corner_radius=5, width=100, height=80).grid(row=row+1, column=0, padx=2, pady=2)
            
            for col, jour in enumerate(JOURS_SEMAINE):
                seances_cellule = [s for s in seances if s.jour == jour and s.creneau_id == creneau.id]
                cellule = ctk.CTkFrame(self.frame_grille, fg_color=COULEURS["fond"],
                                       corner_radius=5, width=140, height=80)
                cellule.grid(row=row+1, column=col+1, padx=2, pady=2, sticky="nsew")
                cellule.pack_propagate(False)
                
                if seances_cellule:
                    seance = seances_cellule[0]
                    module = self.gestionnaire.trouver_module_par_id(seance.module_id)
                    salle = self.gestionnaire.trouver_salle_par_id(seance.salle_id)
                    enseignant = self.gestionnaire.trouver_enseignant_par_id(seance.enseignant_id)
                    
                    if module:
                        couleur = COULEURS_SEANCES.get(module.type_seance, "#9C27B0")
                        info = ctk.CTkFrame(cellule, fg_color=couleur, corner_radius=5)
                        info.pack(fill="both", expand=True, padx=3, pady=3)
                        
                        nom_module = module.nom[:18] + "..." if len(module.nom) > 18 else module.nom
                        ctk.CTkLabel(info, text=nom_module, font=ctk.CTkFont(size=10, weight="bold"),
                                     text_color="white").pack(pady=(5, 1))
                        ctk.CTkLabel(info, text=f"{salle.nom if salle else '?'}",
                                     font=ctk.CTkFont(size=9), text_color="white").pack()
                        
                        if enseignant:
                            user_ens = self.gestionnaire.trouver_utilisateur_par_id(enseignant.utilisateur_id)
                            if user_ens:
                                ctk.CTkLabel(info, text=f"👨‍{user_ens.nom}",
                                             font=ctk.CTkFont(size=9), text_color="white").pack()
    
    def _afficher_recherche_salle(self):
        """Affiche l'interface de recherche de salle libre."""
        self._vider_contenu()
        
        ctk.CTkLabel(self.zone_contenu, text="Rechercher une Salle Libre",
                     font=ctk.CTkFont(size=18, weight="bold")).pack(anchor="w", padx=20, pady=15)
        
        # Description
        ctk.CTkLabel(self.zone_contenu, 
                     text="Trouvez une salle libre pour vos révisions ou travaux de groupe",
                     font=ctk.CTkFont(size=13), text_color=COULEURS["texte_secondaire"]
                     ).pack(anchor="w", padx=20, pady=(0, 15))
        
        # Critères
        frame_criteres = ctk.CTkFrame(self.zone_contenu, fg_color=COULEURS["fond"], corner_radius=10)
        frame_criteres.pack(fill="x", padx=20, pady=10)
        
        inputs = ctk.CTkFrame(frame_criteres, fg_color="transparent")
        inputs.pack(pady=15)
        
        ctk.CTkLabel(inputs, text="Jour:").pack(side="left", padx=5)
        self.var_rech_jour = ctk.StringVar(value="Tous")
        ctk.CTkComboBox(inputs, values=["Tous"] + [JOURS_LABELS[j] for j in JOURS_SEMAINE],
                        variable=self.var_rech_jour, width=120).pack(side="left", padx=5)
        
        ctk.CTkLabel(inputs, text="Créneau:").pack(side="left", padx=(15, 5))
        creneaux = self.gestionnaire.charger_creneaux()
        self.var_rech_creneau = ctk.StringVar(value="Tous")
        ctk.CTkComboBox(inputs, values=["Tous"] + [c.label for c in creneaux],
                        variable=self.var_rech_creneau, width=140).pack(side="left", padx=5)
        
        ctk.CTkButton(inputs, text="Rechercher", fg_color="#9C27B0", hover_color="#7B1FA2",
                      command=self._executer_recherche_etudiant).pack(side="left", padx=20)
        
        # Résultats
        self.frame_resultats = ctk.CTkScrollableFrame(self.zone_contenu, fg_color="transparent")
        self.frame_resultats.pack(fill="both", expand=True, padx=20, pady=10)
        
        ctk.CTkLabel(self.frame_resultats, 
                     text="Cliquez sur 'Rechercher' pour voir les salles disponibles",
                     text_color=COULEURS["texte_secondaire"]).pack(pady=50)
    
    def _executer_recherche_etudiant(self):
        """Exécute la recherche de salles libres."""
        for w in self.frame_resultats.winfo_children():
            w.destroy()
        
        jour_label = self.var_rech_jour.get()
        creneau_label = self.var_rech_creneau.get()
        
        jours = JOURS_SEMAINE if jour_label == "Tous" else [j for j, l in JOURS_LABELS.items() if l == jour_label]
        creneaux = self.gestionnaire.charger_creneaux()
        if creneau_label != "Tous":
            creneaux = [c for c in creneaux if c.label == creneau_label]
        
        salles = self.gestionnaire.charger_salles()
        seances = self.gestionnaire.charger_seances()
        
        resultats = []
        for salle in salles:
            for jour in jours:
                for creneau in creneaux:
                    if self.detecteur.salle_est_libre(salle.id, jour, creneau.id, seances):
                        resultats.append({
                            'salle': salle,
                            'jour': jour,
                            'creneau': creneau
                        })
        
        if not resultats:
            ctk.CTkLabel(self.frame_resultats, text="Aucune salle libre trouvée avec ces critères",
                         text_color=COULEURS["danger"]).pack(pady=50)
            return
        
        ctk.CTkLabel(self.frame_resultats, text=f"{len(resultats)} créneaux libres trouvés",
                     font=ctk.CTkFont(size=14, weight="bold"), text_color="#9C27B0").pack(anchor="w", pady=(0,10))
        
        # Grouper par salle
        par_salle = {}
        for r in resultats:
            nom = r['salle'].nom
            if nom not in par_salle:
                par_salle[nom] = {'salle': r['salle'], 'creneaux': []}
            par_salle[nom]['creneaux'].append(f"{JOURS_LABELS[r['jour']]} {r['creneau'].label}")
        
        for nom, data in par_salle.items():
            carte = ctk.CTkFrame(self.frame_resultats, fg_color=COULEURS["fond"], corner_radius=10)
            carte.pack(fill="x", pady=5)
            
            ctk.CTkLabel(carte, text=f"{nom}", font=ctk.CTkFont(size=13, weight="bold")
                         ).pack(anchor="w", padx=15, pady=(10, 2))
            ctk.CTkLabel(carte, text=f"Capacité: {data['salle'].capacite} | Type: {data['salle'].type}",
                         font=ctk.CTkFont(size=11), text_color=COULEURS["texte_secondaire"]
                         ).pack(anchor="w", padx=15)
            
            creneaux_txt = ", ".join(data['creneaux'][:4])
            if len(data['creneaux']) > 4:
                creneaux_txt += f" (+{len(data['creneaux'])-4} autres)"
            ctk.CTkLabel(carte, text=f"{creneaux_txt}", font=ctk.CTkFont(size=11),
                         text_color=COULEURS["texte_secondaire"]).pack(anchor="w", padx=15, pady=(2, 10))
