# -*- coding: utf-8 -*-
"""
VueConnexion - Écran de connexion
"""

import customtkinter as ctk
from utilitaires.constantes import COULEURS


class VueConnexion(ctk.CTkFrame):
    """
    Écran de connexion de l'application.
    
    Permet aux utilisateurs de s'authentifier avec leur email et mot de passe.
    """
    
    def __init__(self, parent, application):
        """
        Initialise l'écran de connexion.
        
        Args:
            parent: Widget parent
            application: Instance de l'application principale
        """
        super().__init__(parent, fg_color=COULEURS["fond"])
        self.application = application
        
        self._creer_interface()
    
    def _creer_interface(self):
        """Crée l'interface de connexion."""
        # Conteneur centré
        conteneur_centre = ctk.CTkFrame(self, fg_color="transparent")
        conteneur_centre.place(relx=0.5, rely=0.5, anchor="center")
        
        # Carte de connexion
        carte = ctk.CTkFrame(
            conteneur_centre,
            fg_color=COULEURS["carte"],
            corner_radius=15,
            border_width=1,
            border_color=COULEURS["bordure"]
        )
        carte.pack(padx=40, pady=40)
        
        # Contenu de la carte
        contenu = ctk.CTkFrame(carte, fg_color="transparent")
        contenu.pack(padx=50, pady=40)
        
        # Titre
        titre = ctk.CTkLabel(
            contenu,
            text="🎓 Gestion Emploi du Temps",
            font=ctk.CTkFont(size=24, weight="bold"),
            text_color=COULEURS["primaire"]
        )
        titre.pack(pady=(0, 5))
        
        # Sous-titre
        sous_titre = ctk.CTkLabel(
            contenu,
            text="Connectez-vous pour accéder à votre espace",
            font=ctk.CTkFont(size=13),
            text_color=COULEURS["texte_secondaire"]
        )
        sous_titre.pack(pady=(0, 30))
        
        # Champ email
        label_email = ctk.CTkLabel(
            contenu,
            text="Adresse email",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COULEURS["texte"]
        )
        label_email.pack(anchor="w")
        
        self.champ_email = ctk.CTkEntry(
            contenu,
            width=300,
            height=40,
            placeholder_text="exemple@univ.ma",
            font=ctk.CTkFont(size=13)
        )
        self.champ_email.pack(pady=(5, 15))
        
        # Champ mot de passe
        label_mdp = ctk.CTkLabel(
            contenu,
            text="Mot de passe",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COULEURS["texte"]
        )
        label_mdp.pack(anchor="w")
        
        self.champ_mot_de_passe = ctk.CTkEntry(
            contenu,
            width=300,
            height=40,
            placeholder_text="••••••••",
            show="•",
            font=ctk.CTkFont(size=13)
        )
        self.champ_mot_de_passe.pack(pady=(5, 25))
        
        # Message d'erreur (caché par défaut)
        self.label_erreur = ctk.CTkLabel(
            contenu,
            text="",
            font=ctk.CTkFont(size=12),
            text_color=COULEURS["danger"]
        )
        self.label_erreur.pack(pady=(0, 10))
        
        # Bouton de connexion
        bouton_connexion = ctk.CTkButton(
            contenu,
            text="Se connecter",
            width=300,
            height=45,
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color=COULEURS["primaire"],
            hover_color=COULEURS["primaire_hover"],
            command=self._tenter_connexion
        )
        bouton_connexion.pack(pady=(0, 20))
        
        # Informations de connexion pour les tests
        info_frame = ctk.CTkFrame(contenu, fg_color="#E3F2FD", corner_radius=10)
        info_frame.pack(fill="x", pady=(10, 0))
        
        info_titre = ctk.CTkLabel(
            info_frame,
            text="💡 Comptes de test",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color=COULEURS["primaire"]
        )
        info_titre.pack(pady=(10, 5))
        
        comptes = [
            ("Admin", "admin@univ.ma", "admin123"),
            ("Enseignant", "ahmed.benali@univ.ma", "enseignant123"),
            ("Étudiant", "farouk@univ.ma", "etudiant123")
        ]
        
        for role, email, mdp in comptes:
            info_text = ctk.CTkLabel(
                info_frame,
                text=f"{role}: {email} / {mdp}",
                font=ctk.CTkFont(size=11),
                text_color=COULEURS["texte_secondaire"]
            )
            info_text.pack()
        
        ctk.CTkLabel(info_frame, text="").pack(pady=5)  # Espacement
        
        # Binding pour la touche Entrée
        self.champ_email.bind("<Return>", lambda e: self.champ_mot_de_passe.focus())
        self.champ_mot_de_passe.bind("<Return>", lambda e: self._tenter_connexion())
    
    def _tenter_connexion(self):
        """Tente de connecter l'utilisateur avec les identifiants fournis."""
        email = self.champ_email.get().strip()
        mot_de_passe = self.champ_mot_de_passe.get()
        
        # Validation simple
        if not email or not mot_de_passe:
            self._afficher_erreur("Veuillez remplir tous les champs")
            return
        
        # Authentification
        utilisateur = self.application.gestionnaire.authentifier(email, mot_de_passe)
        
        if utilisateur:
            self.application.connecter_utilisateur(utilisateur)
        else:
            self._afficher_erreur("Email ou mot de passe incorrect")
    
    def _afficher_erreur(self, message: str):
        """
        Affiche un message d'erreur.
        
        Args:
            message: Message d'erreur à afficher
        """
        self.label_erreur.configure(text=message)
