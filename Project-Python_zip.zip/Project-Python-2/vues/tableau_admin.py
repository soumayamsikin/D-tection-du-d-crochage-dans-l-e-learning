# -*- coding: utf-8 -*-
"""
TableauAdmin - Tableau de bord de l'administrateur
"""

import customtkinter as ctk
from tkinter import messagebox
from tkinter import messagebox, filedialog
from controleurs.gestionnaire_donnees import GestionnaireDonnees
from controleurs.generateur_emploi import GenerateurEmploi
from controleurs.detecteur_conflits import DetecteurConflits
from controleurs.exportateur import Exportateur
from modeles.salle import Salle
from modeles.filiere import Filiere
from modeles.groupe import Groupe
from modeles.enseignant import Enseignant
from modeles.utilisateur import Utilisateur
from utilitaires.constantes import (
    COULEURS, JOURS_LABELS, TYPES_SALLES, COULEURS_SEANCES, EQUIPEMENTS, NIVEAUX
)


class TableauAdmin(ctk.CTkFrame):
    """
    Tableau de bord de l'administrateur.
    
    Permet de gérer les emplois du temps, les salles, les enseignants,
    les filières et les réservations.
    """
    
    def __init__(self, parent, application):
        """
        Initialise le tableau de bord administrateur.
        
        Args:
            parent: Widget parent
            application: Instance de l'application principale
        """
        super().__init__(parent, fg_color=COULEURS["fond"])
        self.application = application
        self.gestionnaire = application.gestionnaire
        self.generateur = GenerateurEmploi(self.application.gestionnaire)
        self.detecteur = DetecteurConflits(self.application.gestionnaire)
        self.exportateur = Exportateur(self.application.gestionnaire)
        
        # Variables d'étatctif
        self.menu_actif = "emploi_temps"
        
        self._creer_interface()
    
    def _creer_interface(self):
        """Crée l'interface du tableau de bord."""
        # En-tête
        self._creer_entete()
        
        # Corps principal (menu + contenu)
        corps = ctk.CTkFrame(self, fg_color="transparent")
        corps.pack(fill="both", expand=True, padx=20, pady=10)
        
        # Menu latéral
        self._creer_menu_lateral(corps)
        
        # Zone de contenu
        self.zone_contenu = ctk.CTkFrame(
            corps,
            fg_color=COULEURS["carte"],
            corner_radius=15
        )
        self.zone_contenu.pack(side="left", fill="both", expand=True, padx=(10, 0))
        
        # Afficher le contenu par défaut
        self._afficher_emploi_temps()
    
    def _creer_entete(self):
        """Crée l'en-tête du tableau de bord."""
        entete = ctk.CTkFrame(self, fg_color=COULEURS["primaire"], height=60)
        entete.pack(fill="x")
        entete.pack_propagate(False)
        
        # Contenu de l'en-tête
        contenu = ctk.CTkFrame(entete, fg_color="transparent")
        contenu.pack(fill="both", expand=True, padx=20)
        
        # Titre
        titre = ctk.CTkLabel(
            contenu,
            text="🎓 Administration - Gestion des Emplois du Temps",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color="white"
        )
        titre.pack(side="left", pady=15)
        
        # Informations utilisateur et déconnexion
        frame_user = ctk.CTkFrame(contenu, fg_color="transparent")
        frame_user.pack(side="right", pady=10)
        
        nom_user = ctk.CTkLabel(
            frame_user,
            text=f"{self.application.utilisateur_connecte.nom_complet}",
            font=ctk.CTkFont(size=13),
            text_color="white"
        )
        nom_user.pack(side="left", padx=10)
        
        btn_deconnexion = ctk.CTkButton(
            frame_user,
            text="Déconnexion",
            width=100,
            height=30,
            font=ctk.CTkFont(size=12),
            fg_color="transparent",
            border_width=1,
            border_color="white",
            hover_color=COULEURS["primaire_hover"],
            command=self.application.deconnecter
        )
        btn_deconnexion.pack(side="left")
    
    def _creer_menu_lateral(self, parent):
        """Crée le menu latéral de navigation."""
        menu = ctk.CTkFrame(
            parent,
            fg_color=COULEURS["carte"],
            width=200,
            corner_radius=15
        )
        menu.pack(side="left", fill="y")
        menu.pack_propagate(False)
        
        # Titre du menu
        titre_menu = ctk.CTkLabel(
            menu,
            text="Menu",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=COULEURS["texte"]
        )
        titre_menu.pack(pady=20)
        
        # Options du menu
        options = [
            ("Emploi du temps", "emploi_temps", self._afficher_emploi_temps),
            ("Salles", "salles", self._afficher_salles),
            ("👨‍Enseignants", "enseignants", self._afficher_enseignants),
            ("Filières", "filieres", self._afficher_filieres),
            ("Indisponibilités", "indisponibilites", self._afficher_indisponibilites_enseignants),
            ("Réservations", "reservations", self._afficher_reservations),
            ("Statistiques", "statistiques", self._afficher_statistiques),
        ]
        
        self.boutons_menu = {}
        for texte, id_menu, commande in options:
            btn = ctk.CTkButton(
                menu,
                text=texte,
                width=180,
                height=40,
                font=ctk.CTkFont(size=13),
                fg_color=COULEURS["primaire"] if id_menu == self.menu_actif else "transparent",
                text_color="white" if id_menu == self.menu_actif else COULEURS["texte"],
                hover_color=COULEURS["primaire_hover"],
                anchor="w",
                command=lambda cmd=commande, id=id_menu: self._changer_menu(id, cmd)
            )
            btn.pack(pady=3, padx=10)
            self.boutons_menu[id_menu] = btn
    
    def _changer_menu(self, id_menu, commande):
        """Change le menu actif et affiche le contenu correspondant."""
        # Mettre à jour les styles des boutons
        for id_btn, btn in self.boutons_menu.items():
            if id_btn == id_menu:
                btn.configure(fg_color=COULEURS["primaire"], text_color="white")
            else:
                btn.configure(fg_color="transparent", text_color=COULEURS["texte"])
        
        self.menu_actif = id_menu
        commande()
    
    def _vider_contenu(self):
        """Vide la zone de contenu."""
        for widget in self.zone_contenu.winfo_children():
            widget.destroy()
    
    # ==================== EMPLOI DU TEMPS ====================
    
    def _afficher_emploi_temps(self):
        """Affiche la gestion des emplois du temps."""
        self._vider_contenu()
        
        # En-tête
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        
        titre = ctk.CTkLabel(
            entete,
            text="Gestion des Emplois du Temps",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=COULEURS["texte"]
        )
        titre.pack(side="left")
        
        # Boutons d'action
        frame_actions = ctk.CTkFrame(entete, fg_color="transparent")
        frame_actions.pack(side="right")
        
        btn_generer = ctk.CTkButton(
            frame_actions,
            text="Générer",
            width=100,
            fg_color=COULEURS["secondaire"],
            hover_color=COULEURS["secondaire_hover"],
            command=self._generer_emploi_temps
        )
        btn_generer.pack(side="left", padx=5)
        
        btn_exporter = ctk.CTkButton(
            frame_actions,
            text="Exporter",
            width=100,
            fg_color=COULEURS["accent"],
            hover_color=COULEURS["accent_hover"],
            command=self._exporter_emploi_temps
        )
        btn_exporter.pack(side="left", padx=5)

        btn_supprimer = ctk.CTkButton(
            frame_actions,
            text="Supprimer tout",
            width=120,
            fg_color=COULEURS["danger"],
            hover_color=COULEURS["danger_hover"],
            command=self._supprimer_emploi_temps
        )
        btn_supprimer.pack(side="left", padx=5)
        
        # Filtres
        frame_filtres = ctk.CTkFrame(self.zone_contenu, fg_color=COULEURS["fond"], corner_radius=10)
        frame_filtres.pack(fill="x", padx=20, pady=10)
        
        filtres_inner = ctk.CTkFrame(frame_filtres, fg_color="transparent")
        filtres_inner.pack(pady=15)
        
        # Filtre filière
        filieres = self.gestionnaire.charger_filieres()
        ctk.CTkLabel(filtres_inner, text="Filière:", font=ctk.CTkFont(weight="bold")).pack(side="left", padx=5)
        
        if not hasattr(self, 'filiere_selectionnee'):
            self.filiere_selectionnee = ctk.StringVar()
        
        options_filieres = [f.nom_complet for f in filieres]
        if options_filieres:
            self.filiere_selectionnee.set(options_filieres[0])
        
        combo_filiere = ctk.CTkComboBox(
            filtres_inner,
            values=options_filieres,
            variable=self.filiere_selectionnee,
            width=250,
            command=self._on_filiere_change
        )
        combo_filiere.pack(side="left", padx=10)
        
        # Filtre groupe
        ctk.CTkLabel(filtres_inner, text="Groupe:", font=ctk.CTkFont(weight="bold")).pack(side="left", padx=5)
        
        if not hasattr(self, 'groupe_selectionne'):
            self.groupe_selectionne = ctk.StringVar()
        
        self.combo_groupe_emploi = ctk.CTkComboBox(
            filtres_inner,
            values=[],
            variable=self.groupe_selectionne,
            width=150,
            command=lambda x: self._afficher_grille_emploi_temps()
        )
        self.combo_groupe_emploi.pack(side="left", padx=10)
        
        # Initialiser les groupes
        self._rafraichir_groupes_emploi()
        
        # Zone grille
        self.frame_grille_emploi = ctk.CTkScrollableFrame(
            self.zone_contenu,
            fg_color="transparent"
        )
        self.frame_grille_emploi.pack(fill="both", expand=True, padx=20, pady=10)
        
        self._afficher_grille_emploi_temps()
    
    def _on_filiere_change(self, value):
        """Callback quand la filière change."""
        self._rafraichir_groupes_emploi()
        self._afficher_grille_emploi_temps()
    
    def _rafraichir_groupes_emploi(self):
        """Rafraîchit la liste des groupes selon la filière."""
        filieres = self.gestionnaire.charger_filieres()
        filiere = next((f for f in filieres if f.nom_complet == self.filiere_selectionnee.get()), None)
        
        if filiere:
            groupes = self.gestionnaire.trouver_groupes_par_filiere(filiere.id)
            noms_groupes = [g.nom for g in groupes]
            self.combo_groupe_emploi.configure(values=noms_groupes)
            if noms_groupes:
                self.groupe_selectionne.set(noms_groupes[0])
    
    def _afficher_grille_emploi_temps(self):
        """Affiche la grille de l'emploi du temps pour le groupe sélectionné."""
        # Vérifier que la grille existe
        if not hasattr(self, 'frame_grille_emploi'):
            return
        
        # Vider la grille
        for widget in self.frame_grille_emploi.winfo_children():
            widget.destroy()
        
        # Récupérer le groupe sélectionné
        filieres = self.gestionnaire.charger_filieres()
        filiere = next((f for f in filieres if f.nom_complet == self.filiere_selectionnee.get()), None)
        
        if not filiere:
            ctk.CTkLabel(self.frame_grille_emploi, text="Sélectionnez une filière").pack(pady=50)
            return
        
        groupes = self.gestionnaire.trouver_groupes_par_filiere(filiere.id)
        groupe = next((g for g in groupes if g.nom == self.groupe_selectionne.get()), None)
        
        if not groupe:
            ctk.CTkLabel(self.frame_grille_emploi, text="Sélectionnez un groupe").pack(pady=50)
            return
        
        # Titre du groupe
        ctk.CTkLabel(
            self.frame_grille_emploi,
            text=f"Emploi du temps: {filiere.nom} - {groupe.nom}",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COULEURS["primaire"]
        ).pack(anchor="w", pady=(0, 10))
        
        # Charger les données
        creneaux = self.gestionnaire.charger_creneaux()
        seances = self.gestionnaire.trouver_seances_par_groupe(groupe.id)
        jours = ["lundi", "mardi", "mercredi", "jeudi", "vendredi"]
        
        # Frame grille
        grid_frame = ctk.CTkFrame(self.frame_grille_emploi, fg_color="transparent")
        grid_frame.pack(fill="both", expand=True)
        
        # En-tête des jours
        ctk.CTkLabel(grid_frame, text="", width=100).grid(row=0, column=0, padx=2, pady=2)
        for col, jour in enumerate(jours):
            label = ctk.CTkLabel(
                grid_frame,
                text=JOURS_LABELS.get(jour, jour),
                font=ctk.CTkFont(size=14, weight="bold"),
                fg_color=COULEURS["primaire"],
                text_color="white",
                corner_radius=5,
                width=160,
                height=40
            )
            label.grid(row=0, column=col+1, padx=2, pady=2, sticky="ew")
        
        # Lignes des créneaux
        for row, creneau in enumerate(creneaux):
            # Label du créneaubr
            label_creneau = ctk.CTkLabel(
                grid_frame,
                text=creneau.label,
                font=ctk.CTkFont(size=12),
                fg_color="#E3F2FD",
                corner_radius=5,
                width=110,
                height=90
            )
            label_creneau.grid(row=row+1, column=0, padx=2, pady=2, sticky="nsew")
            
            # Cellules pour chaque jour
            for col, jour in enumerate(jours):
                # Trouver la séance pour ce groupe, créneau et jour
                seance = next(
                    (s for s in seances if s.jour == jour and s.creneau_id == creneau.id),
                    None
                )
                
                cellule = ctk.CTkFrame(
                    grid_frame,
                    fg_color=COULEURS["fond"],
                    corner_radius=5,
                    width=160,
                    height=90
                )
                cellule.grid(row=row+1, column=col+1, padx=2, pady=2, sticky="nsew")
                cellule.pack_propagate(False)
                
                if seance:
                    module = self.gestionnaire.trouver_module_par_id(seance.module_id)
                    salle = self.gestionnaire.trouver_salle_par_id(seance.salle_id)
                    enseignant = self.gestionnaire.trouver_enseignant_par_id(seance.enseignant_id)
                    
                    if module:
                        type_seance = module.type_seance
                        couleur = COULEURS_SEANCES.get(type_seance, COULEURS["primaire"])
                        
                        info_seance = ctk.CTkFrame(cellule, fg_color=couleur, corner_radius=5)
                        info_seance.pack(fill="both", expand=True, padx=3, pady=3)
                        
                        nom_module = module.nom[:22] + "..." if len(module.nom) > 22 else module.nom
                        ctk.CTkLabel(
                            info_seance,
                            text=f"{nom_module}",
                            font=ctk.CTkFont(size=11, weight="bold"),
                            text_color="white"
                        ).pack(pady=(8, 2))
                        
                        salle_nom = salle.nom if salle else "?"
                        ctk.CTkLabel(
                            info_seance,
                            text=f"{salle_nom}",
                            font=ctk.CTkFont(size=9),
                            text_color="white"
                        ).pack()
                        
                        if enseignant:
                            user_ens = self.gestionnaire.trouver_utilisateur_par_id(enseignant.utilisateur_id)
                            if user_ens:
                                ctk.CTkLabel(
                                    info_seance,
                                    text=f"👨‍{user_ens.nom}",
                                    font=ctk.CTkFont(size=9),
                                    text_color="white"
                                ).pack()
    
    def _rafraichir_emploi_temps(self):
        """Rafraîchit l'affichage de l'emploi du temps."""
        self._afficher_emploi_temps()
    
    def _generer_emploi_temps(self):
        """Génère un nouvel emploi du temps."""
        if messagebox.askyesno("Confirmation", "Voulez-vous générer un nouvel emploi du temps ?\nCela remplacera l'existant."):
            try:
                # Récupérer la filière sélectionnée si filtre actif
                filiere_id = None
                if hasattr(self, 'combo_filiere') and self.combo_filiere.get() != "Toutes les filières":
                    nom_filiere = self.combo_filiere.get()
                    for f in self.application.gestionnaire.charger_filieres():
                        if f.nom == nom_filiere:
                            filiere_id = f.id
                            break
                
                seances, erreurs = self.generateur.generer_emploi_temps(filiere_id)
                
                if erreurs:
                    msg = "Génération terminée avec des avertissements :\n" + "\n".join(erreurs[:5])
                    if len(erreurs) > 5:
                        msg += "\n..."
                    messagebox.showwarning("Avertissement", msg)
                else:
                    messagebox.showinfo("Succès", "Emploi du temps généré avec succès !")
                
                self._afficher_emploi_temps()
                
            except Exception as e:
                messagebox.showerror("Erreur", "Erreur lors de la génération : " + str(e))

    def _exporter_emploi_temps(self):
        """Exporte l'emploi du temps affiché."""
        # Demander le format
        formats = [
            ("Fichier PDF", "*.pdf"),
            ("Fichier CSV", "*.csv"),
            ("Fichier JSON", "*.json"),
            ("Image PNG", "*.png")
        ]
        
        fichier = filedialog.asksaveasfilename(
            title="Exporter l'emploi du temps",
            filetypes=formats,
            defaultextension=".pdf"
        )
        
        if not fichier:
            return
            
        try:
            # Récupérer les séances à exporter (filtrées ou toutes)
            seances = self.gestionnaire.charger_seances()
            seances_a_exporter = []
            
            # Appliquer les filtres actuels
            filiere_id = None
            groupe_id = None
            
            # Récupérer la filière sélectionnée
            if hasattr(self, 'filiere_selectionnee'):
                nom_filiere = self.filiere_selectionnee.get()
                for f in self.gestionnaire.charger_filieres():
                    if f.nom_complet == nom_filiere:
                        filiere_id = f.id
                        break
            
            # Récupérer le groupe sélectionné
            if hasattr(self, 'groupe_selectionne'):
                nom_groupe = self.groupe_selectionne.get()
                if nom_groupe != "Tous les groupes":
                    # Chercher le groupe correspondant
                    groupes = self.gestionnaire.charger_groupes()
                    for g in groupes:
                        if g.nom == nom_groupe:
                            # Si on a une filière, vérifier que le groupe en fait partie
                            if filiere_id and g.filiere_id != filiere_id:
                                continue
                            groupe_id = g.id
                            break
            
            # Filtrer les séances
            for s in seances:
                garder = True
                
                # Filtre par filière (via module)
                if filiere_id:
                    module = self.gestionnaire.trouver_module_par_id(s.module_id)
                    if module and module.filiere_id != filiere_id:
                        garder = False
                
                # Filtre par groupe
                if groupe_id and s.groupe_id != groupe_id:
                    garder = False
                
                if garder:
                    seances_a_exporter.append(s)
            
            if not seances_a_exporter:
                messagebox.showwarning("Attention", "Aucune séance à exporter avec les filtres actuels.")
                return
                
            # Exporter selon l'extension
            ext = fichier.split('.')[-1].lower()
            
            if ext == "pdf":
                titre = "Emploi du Temps"
                if hasattr(self, 'filiere_selectionnee'):
                    titre += " - " + self.filiere_selectionnee.get()
                if hasattr(self, 'groupe_selectionne') and self.groupe_selectionne.get() != "Tous les groupes":
                    titre += " - " + self.groupe_selectionne.get()
                self.exportateur.exporter_pdf(seances_a_exporter, fichier, titre)
            elif ext == "csv":
                self.exportateur.exporter_csv(seances_a_exporter, fichier)
            elif ext == "json":
                self.exportateur.exporter_json(seances_a_exporter, fichier)
            elif ext == "png":
                self.exportateur.exporter_image(seances_a_exporter, fichier)
                
            messagebox.showinfo("Succès", "Exportation réussie vers " + fichier)
            
        except Exception as e:
            messagebox.showerror("Erreur", "Erreur lors de l'exportation : " + str(e))
    
    def _supprimer_emploi_temps(self):
        """Supprime toutes les séances."""
        if messagebox.askyesno("Confirmation", 
            "Voulez-vous vraiment supprimer toutes les séances ?"):
            nb = self.generateur.supprimer_toutes_seances()
            messagebox.showinfo("Succès", f"{nb} séances supprimées.")
            self._afficher_emploi_temps()
    
    # ==================== SALLES ====================
    
    def _afficher_salles(self):
        """Affiche la gestion des salles."""
        self._vider_contenu()
        
        # En-tête
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        
        titre = ctk.CTkLabel(
            entete,
            text="Gestion des Salles",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=COULEURS["texte"]
        )
        titre.pack(side="left")
        
        # Bouton ajouter
        btn_ajouter = ctk.CTkButton(
            entete,
            text="Ajouter une salle",
            fg_color=COULEURS["secondaire"],
            hover_color=COULEURS["secondaire_hover"],
            command=self._formulaire_salle
        )
        btn_ajouter.pack(side="right")
        
        # Liste des salles
        frame_liste = ctk.CTkScrollableFrame(
            self.zone_contenu,
            fg_color="transparent"
        )
        frame_liste.pack(fill="both", expand=True, padx=20, pady=10)
        
        salles = self.gestionnaire.charger_salles()
        
        # En-tête du tableau
        headers = ["Nom", "Type", "Capacité", "Équipements", "Actions"]
        for col, header in enumerate(headers):
            label = ctk.CTkLabel(
                frame_liste,
                text=header,
                font=ctk.CTkFont(size=13, weight="bold"),
                fg_color=COULEURS["primaire"],
                text_color="white",
                corner_radius=5,
                height=35
            )
            label.grid(row=0, column=col, padx=2, pady=2, sticky="ew")
        
        # Données
        for row, salle in enumerate(salles):
            # Nom
            ctk.CTkLabel(
                frame_liste,
                text=salle.nom,
                font=ctk.CTkFont(size=12),
                fg_color=COULEURS["fond"],
                corner_radius=3,
                height=35
            ).grid(row=row+1, column=0, padx=2, pady=2, sticky="ew")
            
            # Type
            ctk.CTkLabel(
                frame_liste,
                text=TYPES_SALLES.get(salle.type, salle.type),
                font=ctk.CTkFont(size=12),
                fg_color=COULEURS["fond"],
                corner_radius=3,
                height=35
            ).grid(row=row+1, column=1, padx=2, pady=2, sticky="ew")
            
            # Capacité
            ctk.CTkLabel(
                frame_liste,
                text=str(salle.capacite),
                font=ctk.CTkFont(size=12),
                fg_color=COULEURS["fond"],
                corner_radius=3,
                height=35
            ).grid(row=row+1, column=2, padx=2, pady=2, sticky="ew")
            
            # Équipements
            equips = ", ".join(salle.equipements) if salle.equipements else "Aucun"
            ctk.CTkLabel(
                frame_liste,
                text=equips,
                font=ctk.CTkFont(size=11),
                fg_color=COULEURS["fond"],
                corner_radius=3,
                height=35
            ).grid(row=row+1, column=3, padx=2, pady=2, sticky="ew")
            
            # Actions
            frame_actions = ctk.CTkFrame(frame_liste, fg_color=COULEURS["fond"])
            frame_actions.grid(row=row+1, column=4, padx=2, pady=2, sticky="ew")
            
            ctk.CTkButton(
                frame_actions, text="✏️", width=35, height=30,
                fg_color=COULEURS["warning"], hover_color=COULEURS["warning_hover"],
                command=lambda s=salle: self._modifier_salle(s)
            ).pack(side="left", padx=2, pady=2)
            
            ctk.CTkButton(
                frame_actions, text="🗑️", width=35, height=30,
                fg_color=COULEURS["danger"], hover_color=COULEURS["danger_hover"],
                command=lambda s=salle: self._supprimer_salle(s)
            ).pack(side="left", padx=2, pady=2)
        
        # Configuration de la grille
        for col in range(5):
            frame_liste.grid_columnconfigure(col, weight=1)
    
    def _formulaire_salle(self):
        """Affiche le formulaire de création de salle."""
        self._vider_contenu()
        
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        
        ctk.CTkButton(entete, text="Retour", fg_color="transparent",
                      text_color=COULEURS["texte"], command=self._afficher_salles).pack(side="left")
        ctk.CTkLabel(entete, text="Nouvelle Salle", font=ctk.CTkFont(size=18, weight="bold")
                     ).pack(side="left", padx=20)
        
        frame = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        frame.pack(padx=40, pady=20, anchor="w")
        
        ctk.CTkLabel(frame, text="Nom de la salle *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_salle_nom = ctk.CTkEntry(frame, width=300, placeholder_text="Ex: Salle TD 104")
        self.entry_salle_nom.pack(anchor="w", pady=(0, 15))
        
        ctk.CTkLabel(frame, text="Type *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.var_salle_type = ctk.StringVar(value="td")
        ctk.CTkComboBox(frame, values=["amphi", "td", "tp"], variable=self.var_salle_type, width=300
                        ).pack(anchor="w", pady=(0, 15))
        
        ctk.CTkLabel(frame, text="Capacité *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_salle_capacite = ctk.CTkEntry(frame, width=300, placeholder_text="Ex: 40")
        self.entry_salle_capacite.pack(anchor="w", pady=(0, 15))
        
        ctk.CTkLabel(frame, text="Équipements", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.equipements_vars = {}
        frame_eq = ctk.CTkFrame(frame, fg_color="transparent")
        frame_eq.pack(anchor="w", pady=(0, 15))
        for eq in EQUIPEMENTS:
            var = ctk.BooleanVar()
            ctk.CTkCheckBox(frame_eq, text=eq, variable=var).pack(side="left", padx=5)
            self.equipements_vars[eq] = var
        
        ctk.CTkButton(frame, text="Créer la salle", fg_color=COULEURS["secondaire"],
                      hover_color=COULEURS["secondaire_hover"], command=self._creer_salle).pack(anchor="w")
    
    def _creer_salle(self):
        """Crée une nouvelle salle."""
        nom = self.entry_salle_nom.get().strip()
        type_salle = self.var_salle_type.get()
        capacite_str = self.entry_salle_capacite.get().strip()
        
        if not nom or not capacite_str:
            messagebox.showerror("Erreur", "Veuillez remplir le nom et la capacité")
            return
        
        try:
            capacite = int(capacite_str)
        except ValueError:
            messagebox.showerror("Erreur", "La capacité doit être un nombre")
            return
        
        equipements = [eq for eq, var in self.equipements_vars.items() if var.get()]
        
        salle = Salle(
            id=self.gestionnaire.generer_id("S"),
            nom=nom,
            type=type_salle,
            capacite=capacite,
            equipements=equipements
        )
        
        salles = self.gestionnaire.charger_salles()
        salles.append(salle)
        self.gestionnaire.sauvegarder_salles(salles)
        
        messagebox.showinfo("Succès", f"Salle '{nom}' créée avec succès")
        self._afficher_salles()
    
    def _modifier_salle(self, salle):
        """Affiche le formulaire de modification d'une salle."""
        self._vider_contenu()
        
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        
        ctk.CTkButton(entete, text="Retour", fg_color="transparent",
                      text_color=COULEURS["texte"], command=self._afficher_salles).pack(side="left")
        ctk.CTkLabel(entete, text=f"Modifier: {salle.nom}", font=ctk.CTkFont(size=18, weight="bold")
                     ).pack(side="left", padx=20)
        
        frame = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        frame.pack(padx=40, pady=20, anchor="w")
        
        ctk.CTkLabel(frame, text="Nom de la salle *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_salle_nom = ctk.CTkEntry(frame, width=300)
        self.entry_salle_nom.insert(0, salle.nom)
        self.entry_salle_nom.pack(anchor="w", pady=(0, 15))
        
        ctk.CTkLabel(frame, text="Type *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.var_salle_type = ctk.StringVar(value=salle.type)
        ctk.CTkComboBox(frame, values=["amphi", "td", "tp"], variable=self.var_salle_type, width=300
                        ).pack(anchor="w", pady=(0, 15))
        
        ctk.CTkLabel(frame, text="Capacité *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_salle_capacite = ctk.CTkEntry(frame, width=300)
        self.entry_salle_capacite.insert(0, str(salle.capacite))
        self.entry_salle_capacite.pack(anchor="w", pady=(0, 15))
        
        ctk.CTkLabel(frame, text="Équipements", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.equipements_vars = {}
        frame_eq = ctk.CTkFrame(frame, fg_color="transparent")
        frame_eq.pack(anchor="w", pady=(0, 15))
        for eq in EQUIPEMENTS:
            var = ctk.BooleanVar(value=eq in salle.equipements)
            ctk.CTkCheckBox(frame_eq, text=eq, variable=var).pack(side="left", padx=5)
            self.equipements_vars[eq] = var
        
        self.salle_en_cours = salle
        ctk.CTkButton(frame, text="Enregistrer les modifications", fg_color=COULEURS["warning"],
                      hover_color=COULEURS["warning_hover"], command=self._sauvegarder_salle).pack(anchor="w")
    
    def _sauvegarder_salle(self):
        """Sauvegarde les modifications d'une salle."""
        nom = self.entry_salle_nom.get().strip()
        type_salle = self.var_salle_type.get()
        capacite_str = self.entry_salle_capacite.get().strip()
        
        if not nom or not capacite_str:
            messagebox.showerror("Erreur", "Veuillez remplir le nom et la capacité")
            return
        
        try:
            capacite = int(capacite_str)
        except ValueError:
            messagebox.showerror("Erreur", "La capacité doit être un nombre")
            return
        
        equipements = [eq for eq, var in self.equipements_vars.items() if var.get()]
        
        salles = self.gestionnaire.charger_salles()
        for i, s in enumerate(salles):
            if s.id == self.salle_en_cours.id:
                salles[i].nom = nom
                salles[i].type = type_salle
                salles[i].capacite = capacite
                salles[i].equipements = equipements
                break
        
        self.gestionnaire.sauvegarder_salles(salles)
        messagebox.showinfo("Succès", f"Salle '{nom}' modifiée avec succès")
        self._afficher_salles()
    
    def _supprimer_salle(self, salle):
        """Supprime une salle."""
        if messagebox.askyesno("Confirmation", f"Voulez-vous vraiment supprimer la salle '{salle.nom}' ?"):
            salles = self.gestionnaire.charger_salles()
            salles = [s for s in salles if s.id != salle.id]
            self.gestionnaire.sauvegarder_salles(salles)
            messagebox.showinfo("Succès", f"Salle '{salle.nom}' supprimée")
            self._afficher_salles()
    
    # ==================== ENSEIGNANTS ====================
    
    def _afficher_enseignants(self):
        """Affiche la gestion des enseignants."""
        self._vider_contenu()
        
        # En-tête
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        
        titre = ctk.CTkLabel(
            entete,
            text="👨‍Gestion des Enseignants",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=COULEURS["texte"]
        )
        titre.pack(side="left")
        
        # Bouton ajouter
        btn_ajouter = ctk.CTkButton(
            entete,
            text="Ajouter un enseignant",
            fg_color=COULEURS["secondaire"],
            hover_color=COULEURS["secondaire_hover"],
            command=self._formulaire_enseignant
        )
        btn_ajouter.pack(side="right")
        
        # Liste des enseignants
        frame_liste = ctk.CTkScrollableFrame(
            self.zone_contenu,
            fg_color="transparent"
        )
        frame_liste.pack(fill="both", expand=True, padx=20, pady=10)
        
        enseignants = self.gestionnaire.charger_enseignants()
        
        # En-tête du tableau
        headers = ["Nom", "Spécialisation", "Modules", "Indisponibilités", "Actions"]
        for col, header in enumerate(headers):
            label = ctk.CTkLabel(
                frame_liste,
                text=header,
                font=ctk.CTkFont(size=13, weight="bold"),
                fg_color=COULEURS["primaire"],
                text_color="white",
                corner_radius=5,
                height=35
            )
            label.grid(row=0, column=col, padx=2, pady=2, sticky="ew")
        
        # Données
        for row, enseignant in enumerate(enseignants):
            utilisateur = self.gestionnaire.trouver_utilisateur_par_id(enseignant.utilisateur_id)
            nom = utilisateur.nom_complet if utilisateur else "?"
            
            # Nom
            ctk.CTkLabel(
                frame_liste,
                text=nom,
                font=ctk.CTkFont(size=12),
                fg_color=COULEURS["fond"],
                corner_radius=3,
                height=35
            ).grid(row=row+1, column=0, padx=2, pady=2, sticky="ew")
            
            # Spécialisation
            ctk.CTkLabel(
                frame_liste,
                text=enseignant.specialisation,
                font=ctk.CTkFont(size=12),
                fg_color=COULEURS["fond"],
                corner_radius=3,
                height=35
            ).grid(row=row+1, column=1, padx=2, pady=2, sticky="ew")
            
            # Modules
            nb_modules = len(enseignant.modules)
            ctk.CTkLabel(
                frame_liste,
                text=f"{nb_modules} module(s)",
                font=ctk.CTkFont(size=12),
                fg_color=COULEURS["fond"],
                corner_radius=3,
                height=35
            ).grid(row=row+1, column=2, padx=2, pady=2, sticky="ew")
            
            # Indisponibilités
            nb_indispo = len(enseignant.indisponibilites)
            ctk.CTkLabel(
                frame_liste,
                text=f"{nb_indispo}" if nb_indispo else "Aucune",
                font=ctk.CTkFont(size=12),
                fg_color=COULEURS["fond"],
                corner_radius=3,
                height=35
            ).grid(row=row+1, column=3, padx=2, pady=2, sticky="ew")
            
            # Actions
            frame_actions = ctk.CTkFrame(frame_liste, fg_color=COULEURS["fond"])
            frame_actions.grid(row=row+1, column=4, padx=2, pady=2, sticky="ew")
            
            ctk.CTkButton(
                frame_actions, text="✏️", width=35, height=30,
                fg_color=COULEURS["warning"], hover_color=COULEURS["warning_hover"],
                command=lambda e=enseignant: self._modifier_enseignant(e)
            ).pack(side="left", padx=2, pady=2)
            
            ctk.CTkButton(
                frame_actions, text="🗑️", width=35, height=30,
                fg_color=COULEURS["danger"], hover_color=COULEURS["danger_hover"],
                command=lambda e=enseignant: self._supprimer_enseignant(e)
            ).pack(side="left", padx=2, pady=2)
        
        for col in range(5):
            frame_liste.grid_columnconfigure(col, weight=1)
    
    def _formulaire_enseignant(self):
        """Affiche le formulaire de création d'enseignant."""
        self._vider_contenu()
        
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        
        ctk.CTkButton(entete, text="Retour", fg_color="transparent",
                      text_color=COULEURS["texte"], command=self._afficher_enseignants).pack(side="left")
        ctk.CTkLabel(entete, text="Nouvel Enseignant", font=ctk.CTkFont(size=18, weight="bold")
                     ).pack(side="left", padx=20)
        
        frame = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        frame.pack(padx=40, pady=20, anchor="w")
        
        ctk.CTkLabel(frame, text="Nom *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_ens_nom = ctk.CTkEntry(frame, width=300)
        self.entry_ens_nom.pack(anchor="w", pady=(0, 10))
        
        ctk.CTkLabel(frame, text="Prénom *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_ens_prenom = ctk.CTkEntry(frame, width=300)
        self.entry_ens_prenom.pack(anchor="w", pady=(0, 10))
        
        ctk.CTkLabel(frame, text="Email *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_ens_email = ctk.CTkEntry(frame, width=300, placeholder_text="exemple@univ.ma")
        self.entry_ens_email.pack(anchor="w", pady=(0, 10))
        
        ctk.CTkLabel(frame, text="Mot de passe *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_ens_mdp = ctk.CTkEntry(frame, width=300, placeholder_text="enseignant123")
        self.entry_ens_mdp.pack(anchor="w", pady=(0, 10))
        
        ctk.CTkLabel(frame, text="Spécialisation *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_ens_spec = ctk.CTkEntry(frame, width=300, placeholder_text="Ex: Informatique")
        self.entry_ens_spec.pack(anchor="w", pady=(0, 15))
        
        ctk.CTkButton(frame, text="Créer l'enseignant", fg_color=COULEURS["secondaire"],
                      hover_color=COULEURS["secondaire_hover"], command=self._creer_enseignant).pack(anchor="w")
    
    def _creer_enseignant(self):
        """Crée un nouvel enseignant."""
        nom = self.entry_ens_nom.get().strip()
        prenom = self.entry_ens_prenom.get().strip()
        email = self.entry_ens_email.get().strip()
        mdp = self.entry_ens_mdp.get().strip()
        spec = self.entry_ens_spec.get().strip()
        
        if not all([nom, prenom, email, mdp, spec]):
            messagebox.showerror("Erreur", "Veuillez remplir tous les champs")
            return
        
        # Vérifier email unique
        if self.gestionnaire.trouver_utilisateur_par_email(email):
            messagebox.showerror("Erreur", "Cet email existe déjà")
            return
        
        # Créer utilisateur
        utilisateur = Utilisateur(
            id=self.gestionnaire.generer_id("U"),
            nom=nom, prenom=prenom, email=email,
            mot_de_passe=mdp, role="enseignant"
        )
        utilisateurs = self.gestionnaire.charger_utilisateurs()
        utilisateurs.append(utilisateur)
        self.gestionnaire.sauvegarder_utilisateurs(utilisateurs)
        
        # Créer enseignant
        enseignant = Enseignant(
            id=self.gestionnaire.generer_id("E"),
            utilisateur_id=utilisateur.id,
            specialisation=spec
        )
        enseignants = self.gestionnaire.charger_enseignants()
        enseignants.append(enseignant)
        self.gestionnaire.sauvegarder_enseignants(enseignants)
        
        messagebox.showinfo("Succès", f"Enseignant '{prenom} {nom}' créé avec succès")
        self._afficher_enseignants()
    
    def _modifier_enseignant(self, enseignant):
        """Affiche le formulaire de modification d'un enseignant."""
        self._vider_contenu()
        utilisateur = self.gestionnaire.trouver_utilisateur_par_id(enseignant.utilisateur_id)
        
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        
        ctk.CTkButton(entete, text="Retour", fg_color="transparent",
                      text_color=COULEURS["texte"], command=self._afficher_enseignants).pack(side="left")
        nom_affiche = utilisateur.nom_complet if utilisateur else "?"
        ctk.CTkLabel(entete, text=f"Modifier: {nom_affiche}", font=ctk.CTkFont(size=18, weight="bold")
                     ).pack(side="left", padx=20)
        
        frame = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        frame.pack(padx=40, pady=20, anchor="w")
        
        if utilisateur:
            ctk.CTkLabel(frame, text="Nom *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
            self.entry_ens_nom = ctk.CTkEntry(frame, width=300)
            self.entry_ens_nom.insert(0, utilisateur.nom)
            self.entry_ens_nom.pack(anchor="w", pady=(0, 10))
            
            ctk.CTkLabel(frame, text="Prénom *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
            self.entry_ens_prenom = ctk.CTkEntry(frame, width=300)
            self.entry_ens_prenom.insert(0, utilisateur.prenom)
            self.entry_ens_prenom.pack(anchor="w", pady=(0, 10))
        
        ctk.CTkLabel(frame, text="Spécialisation *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_ens_spec = ctk.CTkEntry(frame, width=300)
        self.entry_ens_spec.insert(0, enseignant.specialisation)
        self.entry_ens_spec.pack(anchor="w", pady=(0, 15))
        
        self.enseignant_en_cours = enseignant
        self.utilisateur_en_cours = utilisateur
        ctk.CTkButton(frame, text="Enregistrer les modifications", fg_color=COULEURS["warning"],
                      hover_color=COULEURS["warning_hover"], command=self._sauvegarder_enseignant).pack(anchor="w")
    
    def _sauvegarder_enseignant(self):
        """Sauvegarde les modifications d'un enseignant."""
        nom = self.entry_ens_nom.get().strip() if hasattr(self, 'entry_ens_nom') else None
        prenom = self.entry_ens_prenom.get().strip() if hasattr(self, 'entry_ens_prenom') else None
        spec = self.entry_ens_spec.get().strip()
        
        if not spec:
            messagebox.showerror("Erreur", "Veuillez remplir la spécialisation")
            return
        
        # Mettre à jour utilisateur
        if self.utilisateur_en_cours and nom and prenom:
            utilisateurs = self.gestionnaire.charger_utilisateurs()
            for i, u in enumerate(utilisateurs):
                if u.id == self.utilisateur_en_cours.id:
                    utilisateurs[i].nom = nom
                    utilisateurs[i].prenom = prenom
                    break
            self.gestionnaire.sauvegarder_utilisateurs(utilisateurs)
        
        # Mettre à jour enseignant
        enseignants = self.gestionnaire.charger_enseignants()
        for i, e in enumerate(enseignants):
            if e.id == self.enseignant_en_cours.id:
                enseignants[i].specialisation = spec
                break
        self.gestionnaire.sauvegarder_enseignants(enseignants)
        
        messagebox.showinfo("Succès", "Enseignant modifié avec succès")
        self._afficher_enseignants()
    
    def _supprimer_enseignant(self, enseignant):
        """Supprime un enseignant."""
        utilisateur = self.gestionnaire.trouver_utilisateur_par_id(enseignant.utilisateur_id)
        nom = utilisateur.nom_complet if utilisateur else "cet enseignant"
        
        if messagebox.askyesno("Confirmation", f"Voulez-vous vraiment supprimer {nom} ?"):
            # Supprimer enseignant
            enseignants = self.gestionnaire.charger_enseignants()
            enseignants = [e for e in enseignants if e.id != enseignant.id]
            self.gestionnaire.sauvegarder_enseignants(enseignants)
            
            # Supprimer utilisateur associé
            if utilisateur:
                utilisateurs = self.gestionnaire.charger_utilisateurs()
                utilisateurs = [u for u in utilisateurs if u.id != utilisateur.id]
                self.gestionnaire.sauvegarder_utilisateurs(utilisateurs)
            
            messagebox.showinfo("Succès", f"Enseignant supprimé")
            self._afficher_enseignants()
    
    # ==================== FILIERES ====================
    
    def _afficher_filieres(self):
        """Affiche la gestion des filières."""
        self._vider_contenu()
        
        # En-tête
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        
        titre = ctk.CTkLabel(
            entete,
            text="Gestion des Filières",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=COULEURS["texte"]
        )
        titre.pack(side="left")
        
        # Bouton ajouter
        btn_ajouter = ctk.CTkButton(
            entete,
            text="Ajouter une filière",
            fg_color=COULEURS["secondaire"],
            hover_color=COULEURS["secondaire_hover"],
            command=self._formulaire_filiere
        )
        btn_ajouter.pack(side="right")
        
        # Liste des filières
        frame_liste = ctk.CTkScrollableFrame(
            self.zone_contenu,
            fg_color="transparent"
        )
        frame_liste.pack(fill="both", expand=True, padx=20, pady=10)
        
        filieres = self.gestionnaire.charger_filieres()
        
        for filiere in filieres:
            # Carte de filière
            carte = ctk.CTkFrame(
                frame_liste,
                fg_color=COULEURS["fond"],
                corner_radius=10
            )
            carte.pack(fill="x", pady=5)
            
            # Infos de la filière
            frame_info = ctk.CTkFrame(carte, fg_color="transparent")
            frame_info.pack(fill="x", padx=15, pady=10)
            
            # Titre et boutons actions
            frame_titre = ctk.CTkFrame(frame_info, fg_color="transparent")
            frame_titre.pack(fill="x")
            
            ctk.CTkLabel(
                frame_titre,
                text=f"{filiere.nom_complet}",
                font=ctk.CTkFont(size=14, weight="bold"),
                text_color=COULEURS["texte"]
            ).pack(side="left")
            
            # Boutons actions
            frame_actions = ctk.CTkFrame(frame_titre, fg_color="transparent")
            frame_actions.pack(side="right")
            
            ctk.CTkButton(
                frame_actions, text="✏️", width=35, height=28,
                fg_color=COULEURS["warning"], hover_color=COULEURS["warning_hover"],
                command=lambda f=filiere: self._modifier_filiere(f)
            ).pack(side="left", padx=2)
            
            ctk.CTkButton(
                frame_actions, text="🗑️", width=35, height=28,
                fg_color=COULEURS["danger"], hover_color=COULEURS["danger_hover"],
                command=lambda f=filiere: self._supprimer_filiere(f)
            ).pack(side="left", padx=2)
            
            ctk.CTkLabel(
                frame_info,
                text=filiere.description,
                font=ctk.CTkFont(size=12),
                text_color=COULEURS["texte_secondaire"]
            ).pack(anchor="w")
            
            # Groupes de la filière
            groupes = self.gestionnaire.trouver_groupes_par_filiere(filiere.id)
            frame_groupes = ctk.CTkFrame(carte, fg_color="transparent")
            frame_groupes.pack(fill="x", padx=15, pady=(0, 10))
            
            ctk.CTkLabel(
                frame_groupes,
                text=f"Groupes: ",
                font=ctk.CTkFont(size=12, weight="bold"),
                text_color=COULEURS["texte"]
            ).pack(side="left")
            
            for groupe in groupes:
                badge = ctk.CTkLabel(
                    frame_groupes,
                    text=f"{groupe.nom} ({groupe.nombre_etudiants} étudiants)",
                    font=ctk.CTkFont(size=11),
                    fg_color=COULEURS["primaire"],
                    text_color="white",
                    corner_radius=10,
                    padx=10,
                    pady=2
                )
                badge.pack(side="left", padx=3)
    
    def _formulaire_filiere(self):
        """Affiche le formulaire de création de filière."""
        self._vider_contenu()
        
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        
        ctk.CTkButton(entete, text="Retour", fg_color="transparent",
                      text_color=COULEURS["texte"], command=self._afficher_filieres).pack(side="left")
        ctk.CTkLabel(entete, text="Nouvelle Filière", font=ctk.CTkFont(size=18, weight="bold")
                     ).pack(side="left", padx=20)
        
        frame = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        frame.pack(padx=40, pady=20, anchor="w")
        
        ctk.CTkLabel(frame, text="Nom de la filière *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_fil_nom = ctk.CTkEntry(frame, width=300, placeholder_text="Ex: Informatique")
        self.entry_fil_nom.pack(anchor="w", pady=(0, 10))
        
        ctk.CTkLabel(frame, text="Niveau *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.var_fil_niveau = ctk.StringVar(value="L1")
        ctk.CTkComboBox(frame, values=NIVEAUX, variable=self.var_fil_niveau, width=300).pack(anchor="w", pady=(0, 10))
        
        ctk.CTkLabel(frame, text="Description", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_fil_desc = ctk.CTkEntry(frame, width=300)
        self.entry_fil_desc.pack(anchor="w", pady=(0, 15))
        
        ctk.CTkLabel(frame, text="Nombre de groupes *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_fil_nb_groupes = ctk.CTkEntry(frame, width=300, placeholder_text="Ex: 2")
        self.entry_fil_nb_groupes.pack(anchor="w", pady=(0, 10))
        
        ctk.CTkLabel(frame, text="Étudiants par groupe *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_fil_nb_etudiants = ctk.CTkEntry(frame, width=300, placeholder_text="Ex: 35")
        self.entry_fil_nb_etudiants.pack(anchor="w", pady=(0, 15))
        
        ctk.CTkButton(frame, text="Créer la filière", fg_color=COULEURS["secondaire"],
                      hover_color=COULEURS["secondaire_hover"], command=self._creer_filiere).pack(anchor="w")
    
    def _creer_filiere(self):
        """Crée une nouvelle filière avec ses groupes."""
        nom = self.entry_fil_nom.get().strip()
        niveau = self.var_fil_niveau.get()
        desc = self.entry_fil_desc.get().strip()
        nb_groupes_str = self.entry_fil_nb_groupes.get().strip()
        nb_etudiants_str = self.entry_fil_nb_etudiants.get().strip()
        
        if not nom or not nb_groupes_str or not nb_etudiants_str:
            messagebox.showerror("Erreur", "Veuillez remplir les champs obligatoires")
            return
        
        try:
            nb_groupes = int(nb_groupes_str)
            nb_etudiants = int(nb_etudiants_str)
        except ValueError:
            messagebox.showerror("Erreur", "Les nombres doivent être valides")
            return
        
        # Créer filière
        filiere = Filiere(
            id=self.gestionnaire.generer_id("F"),
            nom=nom, niveau=niveau,
            description=desc or f"{nom} - {niveau}"
        )
        filieres = self.gestionnaire.charger_filieres()
        filieres.append(filiere)
        self.gestionnaire.sauvegarder_filieres(filieres)
        
        # Créer groupes
        groupes = self.gestionnaire.charger_groupes()
        lettres = "ABCDEFGHIJ"
        for i in range(min(nb_groupes, 10)):
            groupe = Groupe(
                id=self.gestionnaire.generer_id("G"),
                nom=f"Groupe {lettres[i]}",
                filiere_id=filiere.id,
                nombre_etudiants=nb_etudiants
            )
            groupes.append(groupe)
        self.gestionnaire.sauvegarder_groupes(groupes)
        
        messagebox.showinfo("Succès", f"Filière '{nom}' créée avec {nb_groupes} groupe(s)")
        self._afficher_filieres()
    
    def _modifier_filiere(self, filiere):
        """Affiche le formulaire de modification d'une filière."""
        self._vider_contenu()
        
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        
        ctk.CTkButton(entete, text="Retour", fg_color="transparent",
                      text_color=COULEURS["texte"], command=self._afficher_filieres).pack(side="left")
        ctk.CTkLabel(entete, text=f"Modifier: {filiere.nom_complet}", font=ctk.CTkFont(size=18, weight="bold")
                     ).pack(side="left", padx=20)
        
        frame = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        frame.pack(padx=40, pady=20, anchor="w")
        
        ctk.CTkLabel(frame, text="Nom de la filière *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_fil_nom = ctk.CTkEntry(frame, width=300)
        self.entry_fil_nom.insert(0, filiere.nom)
        self.entry_fil_nom.pack(anchor="w", pady=(0, 10))
        
        ctk.CTkLabel(frame, text="Niveau *", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.var_fil_niveau = ctk.StringVar(value=filiere.niveau)
        ctk.CTkComboBox(frame, values=NIVEAUX, variable=self.var_fil_niveau, width=300).pack(anchor="w", pady=(0, 10))
        
        ctk.CTkLabel(frame, text="Description", font=ctk.CTkFont(weight="bold")).pack(anchor="w")
        self.entry_fil_desc = ctk.CTkEntry(frame, width=300)
        self.entry_fil_desc.insert(0, filiere.description)
        self.entry_fil_desc.pack(anchor="w", pady=(0, 15))
        
        self.filiere_en_cours = filiere
        ctk.CTkButton(frame, text="Enregistrer les modifications", fg_color=COULEURS["warning"],
                      hover_color=COULEURS["warning_hover"], command=self._sauvegarder_filiere).pack(anchor="w")
    
    def _sauvegarder_filiere(self):
        """Sauvegarde les modifications d'une filière."""
        nom = self.entry_fil_nom.get().strip()
        niveau = self.var_fil_niveau.get()
        desc = self.entry_fil_desc.get().strip()
        
        if not nom:
            messagebox.showerror("Erreur", "Veuillez remplir le nom")
            return
        
        filieres = self.gestionnaire.charger_filieres()
        for i, f in enumerate(filieres):
            if f.id == self.filiere_en_cours.id:
                filieres[i].nom = nom
                filieres[i].niveau = niveau
                filieres[i].description = desc
                break
        
        self.gestionnaire.sauvegarder_filieres(filieres)
        messagebox.showinfo("Succès", f"Filière '{nom}' modifiée avec succès")
        self._afficher_filieres()
    
    def _supprimer_filiere(self, filiere):
        """Supprime une filière et ses groupes."""
        if messagebox.askyesno("Confirmation", f"Voulez-vous vraiment supprimer la filière '{filiere.nom_complet}' et tous ses groupes ?"):
            # Supprimer groupes associés
            groupes = self.gestionnaire.charger_groupes()
            groupes = [g for g in groupes if g.filiere_id != filiere.id]
            self.gestionnaire.sauvegarder_groupes(groupes)
            
            # Supprimer filière
            filieres = self.gestionnaire.charger_filieres()
            filieres = [f for f in filieres if f.id != filiere.id]
            self.gestionnaire.sauvegarder_filieres(filieres)
            
            messagebox.showinfo("Succès", f"Filière '{filiere.nom_complet}' supprimée")
            self._afficher_filieres()
    
    # ==================== INDISPONIBILITÉS ENSEIGNANTS ====================
    
    def _afficher_indisponibilites_enseignants(self):
        """Affiche les indisponibilités de tous les enseignants."""
        self._vider_contenu()
        
        # En-tête
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        
        titre = ctk.CTkLabel(
            entete,
            text="Indisponibilités des Enseignants",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=COULEURS["texte"]
        )
        titre.pack(side="left")
        
        # Liste
        frame_liste = ctk.CTkScrollableFrame(
            self.zone_contenu,
            fg_color="transparent"
        )
        frame_liste.pack(fill="both", expand=True, padx=20, pady=10)
        
        enseignants = self.gestionnaire.charger_enseignants()
        
        # Compter le total des indisponibilités
        total_indispos = sum(len(e.indisponibilites) for e in enseignants)
        
        ctk.CTkLabel(
            frame_liste,
            text=f"Total: {total_indispos} indisponibilité(s) signalée(s)",
            font=ctk.CTkFont(size=13),
            text_color=COULEURS["texte_secondaire"]
        ).pack(anchor="w", pady=(0, 15))
        
        for enseignant in enseignants:
            utilisateur = self.gestionnaire.trouver_utilisateur_par_id(enseignant.utilisateur_id)
            nom = utilisateur.nom_complet if utilisateur else "?"
            
            # Carte de l'enseignant
            carte = ctk.CTkFrame(
                frame_liste,
                fg_color=COULEURS["fond"],
                corner_radius=10
            )
            carte.pack(fill="x", pady=5)
            
            # En-tête de la carte
            frame_header = ctk.CTkFrame(carte, fg_color="transparent")
            frame_header.pack(fill="x", padx=15, pady=10)
            
            nb_indispos = len(enseignant.indisponibilites)
            couleur_badge = COULEURS["danger"] if nb_indispos > 3 else (COULEURS["warning"] if nb_indispos > 0 else COULEURS["secondaire"])
            
            ctk.CTkLabel(
                frame_header,
                text=f"👨‍{nom}",
                font=ctk.CTkFont(size=14, weight="bold"),
                text_color=COULEURS["texte"]
            ).pack(side="left")
            
            ctk.CTkLabel(
                frame_header,
                text=f"{nb_indispos} indisponibilité(s)",
                font=ctk.CTkFont(size=12),
                fg_color=couleur_badge,
                text_color="white",
                corner_radius=10,
                padx=10
            ).pack(side="right")
            
            # Liste des indisponibilités
            if enseignant.indisponibilites:
                frame_indispos = ctk.CTkFrame(carte, fg_color="transparent")
                frame_indispos.pack(fill="x", padx=15, pady=(0, 10))
                
                for indispo in enseignant.indisponibilites:
                    jour = indispo.get('jour', '?')
                    creneau = self.gestionnaire.trouver_creneau_par_id(indispo.get('creneau_id'))
                    motif = indispo.get('motif', '')
                    
                    jour_label = JOURS_LABELS.get(jour, jour)
                    creneau_label = creneau.label if creneau else "?"
                    
                    texte = f"{jour_label} - {creneau_label}"
                    if motif:
                        texte += f" | {motif}"
                    
                    ctk.CTkLabel(
                        frame_indispos,
                        text=texte,
                        font=ctk.CTkFont(size=12),
                        text_color=COULEURS["texte_secondaire"]
                    ).pack(anchor="w", pady=2)
            else:
                ctk.CTkLabel(
                    carte,
                    text="Aucune indisponibilité",
                    font=ctk.CTkFont(size=12),
                    text_color=COULEURS["secondaire"]
                ).pack(anchor="w", padx=15, pady=(0, 10))
    
    # ==================== RESERVATIONS ====================
    
    def _afficher_reservations(self):
        """Affiche la gestion des réservations."""
        self._vider_contenu()
        
        # En-tête
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        
        titre = ctk.CTkLabel(
            entete,
            text="Gestion des Réservations",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=COULEURS["texte"]
        )
        titre.pack(side="left")
        
        # Liste des réservations
        frame_liste = ctk.CTkScrollableFrame(
            self.zone_contenu,
            fg_color="transparent"
        )
        frame_liste.pack(fill="both", expand=True, padx=20, pady=10)
        
        reservations = self.gestionnaire.charger_reservations()
        
        if not reservations:
            ctk.CTkLabel(
                frame_liste,
                text="Aucune demande de réservation",
                font=ctk.CTkFont(size=14),
                text_color=COULEURS["texte_secondaire"]
            ).pack(pady=50)
            return
        
        for reservation in reservations:
            # Carte de réservation
            carte = ctk.CTkFrame(
                frame_liste,
                fg_color=COULEURS["fond"],
                corner_radius=10
            )
            carte.pack(fill="x", pady=5)
            
            frame_contenu = ctk.CTkFrame(carte, fg_color="transparent")
            frame_contenu.pack(fill="x", padx=15, pady=10)
            
            # Enseignant
            enseignant = self.gestionnaire.trouver_enseignant_par_id(reservation.enseignant_id)
            if enseignant:
                utilisateur = self.gestionnaire.trouver_utilisateur_par_id(enseignant.utilisateur_id)
                nom_enseignant = utilisateur.nom_complet if utilisateur else "?"
            else:
                nom_enseignant = "?"
            
            # Salle
            salle = self.gestionnaire.trouver_salle_par_id(reservation.salle_id)
            nom_salle = salle.nom if salle else "?"
            
            # Créneau
            creneau = self.gestionnaire.trouver_creneau_par_id(reservation.creneau_id)
            label_creneau = creneau.label if creneau else "?"
            
            # Infos
            ctk.CTkLabel(
                frame_contenu,
                text=f"👨‍{nom_enseignant} demande la salle {nom_salle}",
                font=ctk.CTkFont(size=13, weight="bold"),
                text_color=COULEURS["texte"]
            ).pack(anchor="w")
            
            ctk.CTkLabel(
                frame_contenu,
                text=f"{reservation.jour.capitalize()} {reservation.date} - {label_creneau}",
                font=ctk.CTkFont(size=12),
                text_color=COULEURS["texte_secondaire"]
            ).pack(anchor="w")
            
            ctk.CTkLabel(
                frame_contenu,
                text=f"Motif: {reservation.motif}",
                font=ctk.CTkFont(size=12),
                text_color=COULEURS["texte_secondaire"]
            ).pack(anchor="w")
            
            # Statut et boutons
            frame_actions = ctk.CTkFrame(frame_contenu, fg_color="transparent")
            frame_actions.pack(anchor="e", pady=(10, 0))
            
            # Badge de statut
            couleur_statut = {
                "en_attente": COULEURS["warning"],
                "acceptee": COULEURS["secondaire"],
                "refusee": COULEURS["danger"]
            }
            
            badge_statut = ctk.CTkLabel(
                frame_actions,
                text=reservation.statut_affichage,
                font=ctk.CTkFont(size=11),
                fg_color=couleur_statut.get(reservation.statut, COULEURS["primaire"]),
                text_color="white",
                corner_radius=10,
                padx=10,
                pady=2
            )
            badge_statut.pack(side="left", padx=5)
            
            if reservation.est_en_attente():
                btn_accepter = ctk.CTkButton(
                    frame_actions,
                    text="✓ Accepter",
                    width=90,
                    height=30,
                    fg_color=COULEURS["secondaire"],
                    hover_color=COULEURS["secondaire_hover"],
                    command=lambda r=reservation: self._accepter_reservation(r)
                )
                btn_accepter.pack(side="left", padx=3)
                
                btn_refuser = ctk.CTkButton(
                    frame_actions,
                    text="✗ Refuser",
                    width=90,
                    height=30,
                    fg_color=COULEURS["danger"],
                    hover_color=COULEURS["danger_hover"],
                    command=lambda r=reservation: self._refuser_reservation(r)
                )
                btn_refuser.pack(side="left", padx=3)
    
    def _accepter_reservation(self, reservation):
        """Accepte une réservation."""
        reservation.accepter()
        self.gestionnaire.mettre_a_jour_reservation(reservation)
        messagebox.showinfo("Succès", "Réservation acceptée")
        self._afficher_reservations()
    
    def _refuser_reservation(self, reservation):
        """Refuse une réservation."""
        reservation.refuser()
        self.gestionnaire.mettre_a_jour_reservation(reservation)
        messagebox.showinfo("Succès", "Réservation refusée")
        self._afficher_reservations()
    
    # ==================== STATISTIQUES ====================
    
    def _afficher_statistiques(self):
        """Affiche les statistiques d'occupation."""
        self._vider_contenu()
        
        # En-tête
        entete = ctk.CTkFrame(self.zone_contenu, fg_color="transparent")
        entete.pack(fill="x", padx=20, pady=15)
        
        titre = ctk.CTkLabel(
            entete,
            text="Statistiques d'Occupation",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=COULEURS["texte"]
        )
        titre.pack(side="left")
        
        # Contenu
        frame_stats = ctk.CTkScrollableFrame(
            self.zone_contenu,
            fg_color="transparent"
        )
        frame_stats.pack(fill="both", expand=True, padx=20, pady=10)
        
        # Obtenir les statistiques
        stats = self.generateur.obtenir_statistiques()
        
        # Cartes de statistiques générales
        frame_cartes = ctk.CTkFrame(frame_stats, fg_color="transparent")
        frame_cartes.pack(fill="x", pady=10)
        
        # Carte: Total séances
        self._creer_carte_stat(
            frame_cartes, "Séances", str(stats['total_seances']), "Total programmées"
        ).pack(side="left", expand=True, fill="x", padx=5)
        
        # Carte: Total salles
        self._creer_carte_stat(
            frame_cartes, "Salles", str(stats['total_salles']), "Disponibles"
        ).pack(side="left", expand=True, fill="x", padx=5)
        
        # Carte: Taux d'occupation
        self._creer_carte_stat(
            frame_cartes, "📈 Occupation", f"{stats['taux_occupation_global']}%", "Taux global"
        ).pack(side="left", expand=True, fill="x", padx=5)
        
        # Occupation par salle
        ctk.CTkLabel(
            frame_stats,
            text="Occupation par Salle",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=COULEURS["texte"]
        ).pack(anchor="w", pady=(20, 10))
        
        for nom_salle, data in stats['occupation_par_salle'].items():
            frame_barre = ctk.CTkFrame(frame_stats, fg_color=COULEURS["fond"], corner_radius=5)
            frame_barre.pack(fill="x", pady=3)
            
            ctk.CTkLabel(
                frame_barre,
                text=f"{nom_salle}",
                font=ctk.CTkFont(size=12),
                width=150
            ).pack(side="left", padx=10, pady=5)
            
            # Barre de progression
            progress = ctk.CTkProgressBar(frame_barre, width=300)
            progress.pack(side="left", padx=10, pady=5)
            progress.set(data['taux'] / 100)
            
            ctk.CTkLabel(
                frame_barre,
                text=f"{data['taux']}% ({data['seances']}/{data['max']})",
                font=ctk.CTkFont(size=11),
                text_color=COULEURS["texte_secondaire"]
            ).pack(side="left", padx=10, pady=5)
        
        # Créneaux les plus chargés
        ctk.CTkLabel(
            frame_stats,
            text="⏰ Créneaux les Plus Chargés",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=COULEURS["texte"]
        ).pack(anchor="w", pady=(20, 10))
        
        for creneau, nb_seances in stats['creneaux_surcharges']:
            ctk.CTkLabel(
                frame_stats,
                text=f"• {creneau}: {nb_seances} séance(s)",
                font=ctk.CTkFont(size=12),
                text_color=COULEURS["texte"]
            ).pack(anchor="w", padx=20)
    
    def _creer_carte_stat(self, parent, titre, valeur, sous_titre):
        """Crée une carte de statistique."""
        carte = ctk.CTkFrame(parent, fg_color=COULEURS["fond"], corner_radius=10)
        
        ctk.CTkLabel(
            carte,
            text=titre,
            font=ctk.CTkFont(size=12),
            text_color=COULEURS["texte_secondaire"]
        ).pack(pady=(15, 5))
        
        ctk.CTkLabel(
            carte,
            text=valeur,
            font=ctk.CTkFont(size=28, weight="bold"),
            text_color=COULEURS["primaire"]
        ).pack()
        
        ctk.CTkLabel(
            carte,
            text=sous_titre,
            font=ctk.CTkFont(size=11),
            text_color=COULEURS["texte_secondaire"]
        ).pack(pady=(5, 15))
        
        return carte
