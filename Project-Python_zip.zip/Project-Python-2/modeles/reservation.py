# -*- coding: utf-8 -*-
"""
Classe Reservation - Représente une demande de réservation de salle
"""


class Reservation:
    """
    Classe représentant une demande de réservation de salle.
    """
    
    STATUTS = ["en_attente", "acceptee", "refusee"]
    
    def __init__(self, id, enseignant_id, salle_id, creneau_id, jour, date, motif, statut="en_attente"):
        """
        Initialise une nouvelle réservation.
        """
        self.id = id
        self.enseignant_id = enseignant_id
        self.salle_id = salle_id
        self.creneau_id = creneau_id
        self.jour = jour
        self.date = date
        self.motif = motif
        self.statut = statut
    
    @property
    def statut_affichage(self):
        """Retourne le statut en format lisible."""
        if self.statut == "en_attente":
            return "En attente"
        elif self.statut == "acceptee":
            return "Acceptée"
        elif self.statut == "refusee":
            return "Refusée"
        return self.statut
    
    def accepter(self):
        """Accepte la réservation."""
        self.statut = "acceptee"
    
    def refuser(self):
        """Refuse la réservation."""
        self.statut = "refusee"
    
    def est_en_attente(self):
        """Vérifie si la réservation est en attente."""
        return self.statut == "en_attente"
    
    def vers_dict(self):
        """Convertit la réservation en dictionnaire."""
        return {
            "id": self.id,
            "enseignant_id": self.enseignant_id,
            "salle_id": self.salle_id,
            "creneau_id": self.creneau_id,
            "jour": self.jour,
            "date": self.date,
            "motif": self.motif,
            "statut": self.statut
        }
    
    @classmethod
    def depuis_dict(cls, data):
        """Crée une réservation à partir d'un dictionnaire."""
        return cls(
            id=data.get("id"),
            enseignant_id=data.get("enseignant_id"),
            salle_id=data.get("salle_id"),
            creneau_id=data.get("creneau_id"),
            jour=data.get("jour"),
            date=data.get("date"),
            motif=data.get("motif"),
            statut=data.get("statut", "en_attente")
        )
    
    def __repr__(self):
        return "Reservation(id=" + str(self.id) + ", statut=" + str(self.statut) + ")"
