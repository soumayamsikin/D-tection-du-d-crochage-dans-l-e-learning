# -*- coding: utf-8 -*-
"""
Classe Utilisateur - Représente un utilisateur du système
"""


class Utilisateur:
    """
    Classe représentant un utilisateur du système.
    """
    
    ROLES_VALIDES = ["admin", "enseignant", "etudiant"]
    
    def __init__(self, id, email, mot_de_passe, nom, prenom, role,
                 filiere_id=None, groupe_id=None):
        """
        Initialise un nouvel utilisateur.
        """
        self.id = id
        self.email = email
        self.mot_de_passe = mot_de_passe
        self.nom = nom
        self.prenom = prenom
        self.role = role
        self.filiere_id = filiere_id
        self.groupe_id = groupe_id
    
    @property
    def nom_complet(self):
        """Retourne le nom complet de l'utilisateur."""
        return self.prenom + " " + self.nom
    
    def verifier_mot_de_passe(self, mot_de_passe):
        """Vérifie si le mot de passe est correct."""
        return self.mot_de_passe == mot_de_passe
    
    def est_admin(self):
        """Vérifie si l'utilisateur est un administrateur."""
        return self.role == "admin"
    
    def est_enseignant(self):
        """Vérifie si l'utilisateur est un enseignant."""
        return self.role == "enseignant"
    
    def est_etudiant(self):
        """Vérifie si l'utilisateur est un étudiant."""
        return self.role == "etudiant"
    
    def vers_dict(self):
        """Convertit l'utilisateur en dictionnaire."""
        data = {
            "id": self.id,
            "email": self.email,
            "mot_de_passe": self.mot_de_passe,
            "nom": self.nom,
            "prenom": self.prenom,
            "role": self.role
        }
        if self.filiere_id:
            data["filiere_id"] = self.filiere_id
        if self.groupe_id:
            data["groupe_id"] = self.groupe_id
        return data
    
    @classmethod
    def depuis_dict(cls, data):
        """Crée un utilisateur à partir d'un dictionnaire."""
        return cls(
            id=data.get("id"),
            email=data.get("email"),
            mot_de_passe=data.get("mot_de_passe"),
            nom=data.get("nom"),
            prenom=data.get("prenom"),
            role=data.get("role"),
            filiere_id=data.get("filiere_id"),
            groupe_id=data.get("groupe_id")
        )
    
    def __repr__(self):
        return "Utilisateur(id=" + str(self.id) + ", email=" + str(self.email) + ", role=" + str(self.role) + ")"
