# -*- coding: utf-8 -*-
"""
Classe Filiere - Représente une filière universitaire
"""


class Filiere:
    """
    Classe représentant une filière universitaire.
    """
    
    def __init__(self, id, nom, niveau, description=""):
        """
        Initialise une nouvelle filière.
        """
        self.id = id
        self.nom = nom
        self.niveau = niveau
        self.description = description
    
    @property
    def nom_complet(self):
        """Retourne le nom complet avec le niveau."""
        return self.nom + " (" + self.niveau + ")"
    
    def vers_dict(self):
        """Convertit la filière en dictionnaire."""
        return {
            "id": self.id,
            "nom": self.nom,
            "niveau": self.niveau,
            "description": self.description
        }
    
    @classmethod
    def depuis_dict(cls, data):
        """Crée une filière à partir d'un dictionnaire."""
        return cls(
            id=data.get("id"),
            nom=data.get("nom"),
            niveau=data.get("niveau"),
            description=data.get("description", "")
        )
    
    def __repr__(self):
        return "Filiere(id=" + str(self.id) + ", nom=" + str(self.nom) + ")"
