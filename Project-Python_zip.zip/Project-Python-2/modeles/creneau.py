# -*- coding: utf-8 -*-
"""
Classe Creneau - Représente un créneau horaire
"""


class Creneau:
    """
    Classe représentant un créneau horaire.
    """
    
    def __init__(self, id, heure_debut, heure_fin, label=""):
        """
        Initialise un nouveau créneau.
        """
        self.id = id
        self.heure_debut = heure_debut
        self.heure_fin = heure_fin
        self.label = label or (heure_debut + " - " + heure_fin)
    
    def vers_dict(self):
        """Convertit le créneau en dictionnaire."""
        return {
            "id": self.id,
            "heure_debut": self.heure_debut,
            "heure_fin": self.heure_fin,
            "label": self.label
        }
    
    @classmethod
    def depuis_dict(cls, data):
        """Crée un créneau à partir d'un dictionnaire."""
        return cls(
            id=data.get("id"),
            heure_debut=data.get("heure_debut"),
            heure_fin=data.get("heure_fin"),
            label=data.get("label", "")
        )
    
    def __repr__(self):
        return "Creneau(id=" + str(self.id) + ", label=" + str(self.label) + ")"
