# -*- coding: utf-8 -*-
"""
Classe Seance - Représente une séance programmée
"""


class Seance:
    """
    Classe représentant une séance de cours programmée.
    """
    
    def __init__(self, id, module_id, salle_id, creneau_id, jour, groupe_id, enseignant_id):
        """
        Initialise une nouvelle séance.
        """
        self.id = id
        self.module_id = module_id
        self.salle_id = salle_id
        self.creneau_id = creneau_id
        self.jour = jour
        self.groupe_id = groupe_id
        self.enseignant_id = enseignant_id
    
    def a_conflit_avec(self, autre_seance):
        """
        Vérifie si cette séance a un conflit avec une autre.
        """
        if self.jour != autre_seance.jour:
            return False
        if self.creneau_id != autre_seance.creneau_id:
            return False
        
        # Conflit de salle
        if self.salle_id == autre_seance.salle_id:
            return True
        # Conflit d'enseignant
        if self.enseignant_id == autre_seance.enseignant_id:
            return True
        # Conflit de groupe
        if self.groupe_id == autre_seance.groupe_id:
            return True
        
        return False
    
    def vers_dict(self):
        """Convertit la séance en dictionnaire."""
        return {
            "id": self.id,
            "module_id": self.module_id,
            "salle_id": self.salle_id,
            "creneau_id": self.creneau_id,
            "jour": self.jour,
            "groupe_id": self.groupe_id,
            "enseignant_id": self.enseignant_id
        }
    
    @classmethod
    def depuis_dict(cls, data):
        """Crée une séance à partir d'un dictionnaire."""
        return cls(
            id=data.get("id"),
            module_id=data.get("module_id"),
            salle_id=data.get("salle_id"),
            creneau_id=data.get("creneau_id"),
            jour=data.get("jour"),
            groupe_id=data.get("groupe_id"),
            enseignant_id=data.get("enseignant_id")
        )
    
    def __repr__(self):
        return "Seance(id=" + str(self.id) + ", jour=" + str(self.jour) + ")"
